# OracleMem Natural Adjudicated Coverage Package

This package is a model-adjudicated subset exported from the primary Natural package. It is intended as a semantic-stability diagnostic, not as human ground truth.
