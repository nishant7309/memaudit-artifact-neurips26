# Actual Letta OpenRouter-Gemini Baseline

- Package: `llm_memory_validation\natural_adjudicated_100_gemini_flash\coverage_package`
- Letta server: `http://127.0.0.1:8283`
- Letta model: `openrouter/google/gemini-2.5-flash-lite`
- Letta embedding: `openrouter/text-embedding-3-small`
- Coverage judge: `google/gemini-3.1-flash-lite-preview`
- Salience judge: `google/gemini-3.1-flash-lite-preview`
- Attempted instances: 87
- Completed scored instances: 87
- Written-store instances: 87
- Failed instances: 0
- Empty scope records: 59 (mostly no core-memory atoms when archival tools were used)
- Primary denominator: exact finite optimum over package candidates plus Letta-written memories (`package_plus_letta_exact_opt`).

| Method | Budget | N | Mean ratio to union OPT | Mean ratio to package-candidate OPT | Mean written memories | Mean store cost | Mean runtime sec |
|---|---:|---:|---:|---:|---:|---:|---:|
| actual_letta_archival_oracle_pruned_upper | 30 | 85 | 0.693 | 0.911 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_oracle_pruned_upper | 60 | 85 | 0.749 | 0.958 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_oracle_pruned_upper | 100 | 85 | 0.772 | 0.921 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_recency_pruned | 30 | 85 | 0.223 | 0.273 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_recency_pruned | 60 | 85 | 0.269 | 0.328 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_recency_pruned | 100 | 85 | 0.365 | 0.429 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_salience_pruned | 30 | 85 | 0.641 | 0.825 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_salience_pruned | 60 | 85 | 0.707 | 0.908 | 8.88 | 241.3 | 74.4 |
| actual_letta_archival_salience_pruned | 100 | 85 | 0.755 | 0.898 | 8.88 | 241.3 | 74.4 |
| actual_letta_combined_oracle_pruned_upper | 30 | 87 | 0.723 | 0.939 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_oracle_pruned_upper | 60 | 87 | 0.763 | 0.975 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_oracle_pruned_upper | 100 | 87 | 0.765 | 0.918 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_recency_pruned | 30 | 87 | 0.219 | 0.274 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_recency_pruned | 60 | 87 | 0.260 | 0.301 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_recency_pruned | 100 | 87 | 0.342 | 0.400 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_salience_pruned | 30 | 87 | 0.652 | 0.846 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_salience_pruned | 60 | 87 | 0.696 | 0.894 | 9.76 | 256.6 | 73.2 |
| actual_letta_combined_salience_pruned | 100 | 87 | 0.734 | 0.881 | 9.76 | 256.6 | 73.2 |
| actual_letta_core_oracle_pruned_upper | 30 | 30 | 0.661 | 0.799 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_oracle_pruned_upper | 60 | 30 | 0.657 | 0.871 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_oracle_pruned_upper | 100 | 30 | 0.652 | 0.802 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_recency_pruned | 30 | 30 | 0.282 | 0.278 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_recency_pruned | 60 | 30 | 0.507 | 0.688 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_recency_pruned | 100 | 30 | 0.641 | 0.789 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_salience_pruned | 30 | 30 | 0.626 | 0.757 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_salience_pruned | 60 | 30 | 0.607 | 0.821 | 3.13 | 60.5 | 60.9 |
| actual_letta_core_salience_pruned | 100 | 30 | 0.613 | 0.761 | 3.13 | 60.5 | 60.9 |

## Claim Boundary

This run demonstrates a production Letta/OpenRouter-Gemini memory writer under the OracleMem denominator. It is not an oracle writer: Letta does not see coverage labels or downstream required evidence units at write time. The oracle-pruned row, when enabled, is an analysis-only upper bound over Letta-written memories.
