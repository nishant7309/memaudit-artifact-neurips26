# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.
- `policy_metadata`: Rows record estimated-policy, local proxy writer, validity-ablation, or candidate-quality-ablation provenance; train/dev estimated rows mark train-time oracle labels separately from dev-time visible-feature decisions and use no external services.
- `retrieval_summary`: Aggregated deterministic retrieval/write decomposition, emitted when --enable-retrieval is used.

## Local Proxy Writer Baselines

- `amem_graph`: proxy for A-Mem-style adaptive graph/evolving memory. Local proxy only: it does not run A-Mem's learned memory evolution, LLM-generated relation expansion, or retrieval-time graph traversal.
- `mem0_extract`: proxy for Mem0-style extraction and consolidation. Local proxy only: it does not run Mem0's extraction model, vector store, graph store, or update pipeline.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `unknown` | 30 | `amem_graph` | 87 | 0.3908 | 0.4808 [0.3812, 0.5824] | 20.52 | 0.00 | yes |
| `unknown` | 30 | `estimated_gvt` | 87 | 0.4598 | 0.5278 [0.4291, 0.6216] | 23.55 | 0.00 | yes |
| `unknown` | 30 | `fact_only` | 87 | 0.7586 | 0.8036 [0.7213, 0.8812] | 12.20 | 0.00 | yes |
| `unknown` | 30 | `mem0_extract` | 87 | 0.5460 | 0.5958 [0.4923, 0.6954] | 20.84 | 0.00 | yes |
| `unknown` | 30 | `opt` | 87 | 0.9598 | 1.0000 [1.0000, 1.0000] | 15.46 | 0.00 | yes |
| `unknown` | 30 | `oracle_gvt` | 87 | 0.9598 | 1.0000 [1.0000, 1.0000] | 15.46 | 0.00 | yes |
| `unknown` | 30 | `recency_raw` | 87 | 0.0000 | 0.1379 [0.0690, 0.2184] | 0.00 | 0.00 | yes |
| `unknown` | 30 | `summary_only` | 87 | 0.1322 | 0.2615 [0.1724, 0.3592] | 3.72 | 0.00 | yes |
| `unknown` | 60 | `amem_graph` | 87 | 0.5230 | 0.3743 [0.2749, 0.4670] | 30.39 | 0.00 | yes |
| `unknown` | 60 | `estimated_gvt` | 87 | 0.9195 | 0.6782 [0.5843, 0.7615] | 49.48 | 0.00 | yes |
| `unknown` | 60 | `fact_only` | 87 | 0.8851 | 0.6082 [0.5182, 0.6973] | 15.68 | 0.00 | yes |
| `unknown` | 60 | `mem0_extract` | 87 | 0.6034 | 0.4159 [0.3268, 0.5057] | 27.87 | 0.00 | yes |
| `unknown` | 60 | `opt` | 87 | 1.3678 | 1.0000 [1.0000, 1.0000] | 28.82 | 0.00 | yes |
| `unknown` | 60 | `oracle_gvt` | 87 | 1.3621 | 0.9962 [0.9885, 1.0000] | 28.53 | 0.00 | yes |
| `unknown` | 60 | `recency_raw` | 87 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 60 | `summary_only` | 87 | 0.9943 | 0.8092 [0.7536, 0.8638] | 38.28 | 0.00 | yes |
| `unknown` | 100 | `amem_graph` | 87 | 0.5690 | 0.3774 [0.2841, 0.4665] | 31.71 | 0.00 | yes |
| `unknown` | 100 | `estimated_gvt` | 87 | 1.2069 | 0.8290 [0.7609, 0.8868] | 68.66 | 0.00 | yes |
| `unknown` | 100 | `fact_only` | 87 | 0.8851 | 0.5951 [0.5038, 0.6834] | 15.68 | 0.00 | yes |
| `unknown` | 100 | `mem0_extract` | 87 | 0.6092 | 0.4135 [0.3246, 0.5029] | 28.84 | 0.00 | yes |
| `unknown` | 100 | `opt` | 87 | 1.4885 | 1.0000 [1.0000, 1.0000] | 33.93 | 0.00 | yes |
| `unknown` | 100 | `oracle_gvt` | 87 | 1.4885 | 1.0000 [1.0000, 1.0000] | 33.93 | 0.00 | yes |
| `unknown` | 100 | `recency_raw` | 87 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 100 | `summary_only` | 87 | 1.3506 | 0.9412 [0.9023, 0.9718] | 55.43 | 0.00 | yes |

## Best Method by Budget

- `unknown`, budget 30: `opt` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 60: `opt` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 100: `opt` with mean `ratio_to_opt=1.0000`.
