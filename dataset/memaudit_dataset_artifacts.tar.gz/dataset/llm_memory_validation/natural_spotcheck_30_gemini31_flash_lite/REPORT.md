# Natural Package Adjudication Report

- Adjudicator model: `google/gemini-3.1-flash-lite-preview`
- Attempted examples: 30
- Accepted/corrected examples exported: 29
- Rejected/ambiguous examples: 1
- Required-unit changed rate: 0.033
- API total tokens: 201301
- API cost reported by OpenRouter: $0.0639

## Status Counts

- `accepted`: 28
- `corrected`: 1
- `rejected`: 1

## Adjudicated Package Scores

| Budget | Method | N | Mean ratio to exact package OPT | Bootstrap 95% CI |
|---:|---|---:|---:|---|
| 30 | `amac_admission` | 29 | 0.724 | [0.552, 0.897] |
| 30 | `estimated_gvt` | 29 | 0.655 | [0.483, 0.828] |
| 30 | `fact_only` | 29 | 0.793 | [0.655, 0.931] |
| 30 | `opt` | 29 | 1.000 | [1.000, 1.000] |
| 30 | `oracle_gvt` | 29 | 1.000 | [1.000, 1.000] |
| 30 | `recency_raw` | 29 | 0.552 | [0.379, 0.724] |
| 30 | `summary_only` | 29 | 0.586 | [0.414, 0.759] |
| 60 | `amac_admission` | 29 | 0.483 | [0.276, 0.672] |
| 60 | `estimated_gvt` | 29 | 0.603 | [0.431, 0.759] |
| 60 | `fact_only` | 29 | 0.569 | [0.379, 0.741] |
| 60 | `opt` | 29 | 1.000 | [1.000, 1.000] |
| 60 | `oracle_gvt` | 29 | 1.000 | [1.000, 1.000] |
| 60 | `recency_raw` | 29 | 0.345 | [0.172, 0.517] |
| 60 | `summary_only` | 29 | 0.897 | [0.793, 0.983] |
| 100 | `amac_admission` | 29 | 0.483 | [0.276, 0.672] |
| 100 | `estimated_gvt` | 29 | 0.724 | [0.552, 0.879] |
| 100 | `fact_only` | 29 | 0.569 | [0.379, 0.741] |
| 100 | `opt` | 29 | 1.000 | [1.000, 1.000] |
| 100 | `oracle_gvt` | 29 | 1.000 | [1.000, 1.000] |
| 100 | `recency_raw` | 29 | 0.345 | [0.172, 0.517] |
| 100 | `summary_only` | 29 | 0.891 | [0.787, 0.977] |

## Claim Boundary

This is model adjudication with Gemini Flash, not human ground truth. It is useful as a stricter semantic-stability diagnostic than the primary single-annotator package, but any main-paper claim should still call it model-adjudicated rather than human-adjudicated.
