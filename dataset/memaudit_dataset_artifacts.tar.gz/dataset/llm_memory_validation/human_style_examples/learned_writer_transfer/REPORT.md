# Learned Writer Transfer Report

This run trains a local visible-feature utility estimator on train-only oracle labels and evaluates held-out memory-writing decisions against exact finite-package OPT.

## Train Data

- Synthetic train instances: 1000
- Natural train instances: 200
- Total train instances: 1200
- Train candidates: 22106
- Ridge: 0.25
- Test package: `llm_memory_validation\human_style_examples\examples_100.jsonl`

## Claim Boundary

- Oracle coverage is used to create train labels only.
- Held-out estimated-writer decisions use visible candidate metadata only.
- The human-edited test package is schema-valid and exact-scored, but it is not an inter-annotator agreement study.

## Held-Out Package Ratios

### Budget 150
- `amac_admission`: ratio_to_opt=0.533, objective=8.000, cost=148.0
- `amem_graph`: ratio_to_opt=0.667, objective=10.000, cost=147.0
- `density_only`: ratio_to_opt=0.600, objective=9.000, cost=150.0
- `estimated_gvt`: ratio_to_opt=0.933, objective=14.000, cost=146.0
- `estimated_utility`: ratio_to_opt=0.867, objective=13.000, cost=147.0
- `fact_only`: ratio_to_opt=0.333, objective=5.000, cost=92.0
- `greedy`: ratio_to_opt=1.000, objective=15.000, cost=141.0
- `mem0_extract`: ratio_to_opt=0.267, objective=4.000, cost=147.0
- `memgpt_tiered`: ratio_to_opt=0.400, objective=6.000, cost=143.0
- `no_tombstone_opt`: ratio_to_opt=0.867, objective=13.000, cost=150.0
- `opt`: ratio_to_opt=1.000, objective=15.000, cost=141.0
- `oracle_gvt`: ratio_to_opt=1.000, objective=15.000, cost=141.0
- `recency_raw`: ratio_to_opt=0.000, objective=0.000, cost=0.0
- `summary_only`: ratio_to_opt=0.000, objective=0.000, cost=0.0

### Budget 300
- `amac_admission`: ratio_to_opt=0.593, objective=16.000, cost=291.0
- `amem_graph`: ratio_to_opt=0.741, objective=20.000, cost=292.0
- `density_only`: ratio_to_opt=0.667, objective=18.000, cost=299.0
- `estimated_gvt`: ratio_to_opt=0.926, objective=25.000, cost=293.0
- `estimated_utility`: ratio_to_opt=0.852, objective=23.000, cost=298.0
- `fact_only`: ratio_to_opt=0.185, objective=5.000, cost=92.0
- `greedy`: ratio_to_opt=1.000, objective=27.000, cost=289.0
- `mem0_extract`: ratio_to_opt=0.444, objective=12.000, cost=297.0
- `memgpt_tiered`: ratio_to_opt=0.481, objective=13.000, cost=294.0
- `no_tombstone_opt`: ratio_to_opt=0.815, objective=22.000, cost=285.0
- `opt`: ratio_to_opt=1.000, objective=27.000, cost=289.0
- `oracle_gvt`: ratio_to_opt=0.963, objective=26.000, cost=295.0
- `recency_raw`: ratio_to_opt=0.000, objective=0.000, cost=0.0
- `summary_only`: ratio_to_opt=0.000, objective=0.000, cost=0.0

### Budget 600
- `amac_admission`: ratio_to_opt=0.625, objective=30.000, cost=600.0
- `amem_graph`: ratio_to_opt=0.750, objective=36.000, cost=599.0
- `density_only`: ratio_to_opt=0.854, objective=41.000, cost=599.0
- `estimated_gvt`: ratio_to_opt=0.854, objective=41.000, cost=600.0
- `estimated_utility`: ratio_to_opt=0.812, objective=39.000, cost=599.0
- `fact_only`: ratio_to_opt=0.104, objective=5.000, cost=92.0
- `greedy`: ratio_to_opt=1.000, objective=48.000, cost=585.0
- `mem0_extract`: ratio_to_opt=0.542, objective=26.000, cost=600.0
- `memgpt_tiered`: ratio_to_opt=0.542, objective=26.000, cost=598.0
- `no_tombstone_opt`: ratio_to_opt=0.812, objective=39.000, cost=592.0
- `opt`: ratio_to_opt=1.000, objective=48.000, cost=585.0
- `oracle_gvt`: ratio_to_opt=0.958, objective=46.000, cost=595.0
- `recency_raw`: ratio_to_opt=0.000, objective=0.000, cost=0.0
- `summary_only`: ratio_to_opt=0.000, objective=0.000, cost=0.0

### Budget 1000
- `amac_admission`: ratio_to_opt=0.667, objective=48.000, cost=987.0
- `amem_graph`: ratio_to_opt=0.708, objective=51.000, cost=988.0
- `density_only`: ratio_to_opt=0.889, objective=64.000, cost=998.0
- `estimated_gvt`: ratio_to_opt=0.792, objective=57.000, cost=999.0
- `estimated_utility`: ratio_to_opt=0.778, objective=56.000, cost=990.0
- `fact_only`: ratio_to_opt=0.069, objective=5.000, cost=92.0
- `greedy`: ratio_to_opt=1.000, objective=72.000, cost=984.0
- `mem0_extract`: ratio_to_opt=0.708, objective=51.000, cost=993.0
- `memgpt_tiered`: ratio_to_opt=0.625, objective=45.000, cost=998.0
- `no_tombstone_opt`: ratio_to_opt=0.625, objective=45.000, cost=741.0
- `opt`: ratio_to_opt=1.000, objective=72.000, cost=984.0
- `oracle_gvt`: ratio_to_opt=1.000, objective=72.000, cost=993.0
- `recency_raw`: ratio_to_opt=0.000, objective=0.000, cost=0.0
- `summary_only`: ratio_to_opt=0.000, objective=0.000, cost=0.0
