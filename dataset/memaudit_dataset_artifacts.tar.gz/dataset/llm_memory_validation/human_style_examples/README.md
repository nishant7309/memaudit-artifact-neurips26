# Human-Edited OracleMem Natural Examples

This folder contains a 100-example JSONL seed set for human-edited OracleMem
annotation work. The examples are fictional and are intended to stress
long-term memory writing, updates, stale facts, tombstones, temporal validity,
privacy/deletion requests, and abstention.

Files:

- `examples_part_a.jsonl`: records `human_natural_000` through `human_natural_049`.
- `examples_part_b.jsonl`: records `human_natural_050` through `human_natural_099`.
- `examples_100.jsonl`: canonical combined file with 100 records.
- `eval_package_100/`: exact package evaluation outputs for the combined file.
- `coverage_package/`: exported machine-checkable coverage package.
- `writer_adapters/`: zero-API Letta/MemGPT-style, A-Mem-style, Mem0-style, and A-MAC-style adapter evaluation on the exported package.
- `actual_amem_gemini_flash_100/`: public A-Mem execution on the exported package.

Canonical schema:

- `example_id`
- `domain`
- `sessions`
- `future_query`
- `evidence_units`
- `candidate_memories`
- `required_unit_ids_for_query`
- `annotation_notes`
- `audit_checklist`

Validation:

```powershell
python scripts\validate_human_style_examples.py llm_memory_validation\human_style_examples\examples_100.jsonl
```

Evaluation:

```powershell
python llm_memory_validation\evaluate_human_style_examples.py --examples-jsonl llm_memory_validation\human_style_examples\examples_100.jsonl --out-dir llm_memory_validation\human_style_examples\eval_package_100 --budgets 150,300,600,1000 --methods opt,oracle_gvt,estimated_gvt,amac_admission,mem0_extract,density_only,greedy,fact_only,summary_only,recency_raw,no_tombstone_opt
```

Learned writer transfer diagnostic:

```powershell
python llm_memory_validation\evaluate_learned_writer_transfer.py --out-dir llm_memory_validation\human_style_examples\learned_writer_transfer --budgets 150,300,600,1000 --methods opt,oracle_gvt,estimated_gvt,estimated_utility,memgpt_tiered,amem_graph,amac_admission,mem0_extract,density_only,greedy,fact_only,summary_only,recency_raw,no_tombstone_opt
```

This trains a local visible-feature estimator on synthetic plus Natural-200
train labels and evaluates held-out decisions on this package without hidden
coverage access at test time.

Training-source ablations are in `learned_writer_transfer_synth_only/` and
`learned_writer_transfer_natural_only/`. Current Estimated-GVT ratios are
`0.667/0.778/0.792/0.833` for synthetic-only training and
`0.000/0.074/0.375/0.486` for Natural-200-only training, compared with
`0.933/0.926/0.854/0.792` for combined training.

System-adapter diagnostic on the exported coverage package:

```powershell
python llm_memory_validation\evaluate_coverage_package_writers.py --package-dir llm_memory_validation\human_style_examples\coverage_package --out-dir llm_memory_validation\human_style_examples\writer_adapters --budgets 150,300,600,1000 --methods opt,oracle_gvt,memgpt_tiered,amem_graph,mem0_extract,amac_admission,estimated_gvt,density_only,summary_only,fact_only,recency_raw
```

Current adapter result: Letta/MemGPT-style reaches `0.847`, A-Mem-style reaches
`0.876`, Mem0-style reaches `0.753`, and A-MAC-style reaches `0.835` ratio to
exact package OPT on 85 query-resolved examples. Density-only is `1.000`, so
this is a reproducibility/protocol check rather than evidence that system-style
adapters dominate cheap-density selection on this package.

Current validation result:

- 100 records.
- Domain distribution: 20 preference-update, 15 scheduling/commitment, 15 tool-result/task-state, 15 stale-fact/correction, 10 procedural preference, 10 privacy/deletion/do-not-store, 10 temporal validity, 5 abstention-only.
- Structural errors: none.
- Exact package evaluation: `eval_package_100/raw_results.jsonl`, `summary.json`, `summary.md`, and `REPORT.md`.
- Exported package adapter evaluation: `writer_adapters/raw_results.jsonl`, `summary.json`, `summary.md`, and `REPORT.md`.

Important caveat: this is a human-edited/audited seed set, not an
inter-annotator agreement study. For paper claims, use it as evidence that the
schema can support manual annotation and exact finite-package scoring, not as a
claim of broad natural-ground-truth agreement.
