# LongMemEval-S Frozen-Context Reader Evaluation

- Reader: `openrouter` / `openai/gpt-5.5`.
- Scope: API reader evaluation on frozen contexts.
- Contexts: reconstructed from frozen top-5 retrieval ids without re-retrieval.
- Metrics: exact match and token F1 against LongMemEval-S answers; evidence-use checks whether cited memory ids overlap gold answer-session ids.

## Focus Reader Results

| Method | Overall EM | Focus EM | Focus F1 | Evidence use | Unsupported answer | Insufficient rate | Parse fail | Avg context words | Cost |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| OracleMem writer + dense retrieval | 0.0521 | 0.0521 | 0.2918 | 0.7346 | 0.0284 | 0.2559 | 0.0047 | 965.6 | $2.4098 |
| Full raw-store dense retrieval | 0.0427 | 0.0427 | 0.2234 | 0.6114 | 0.0000 | 0.4408 | 0.0000 | 1591.6 | $3.3125 |
| Budgeted raw replay + dense retrieval | 0.0095 | 0.0095 | 0.0360 | 0.1232 | 0.0095 | 0.8768 | 0.0000 | 1568.7 | $3.0946 |
| FIFO raw replay | 0.0190 | 0.0190 | 0.0620 | 0.1706 | 0.0000 | 0.8531 | 0.0000 | 1582.6 | $2.9835 |

## Paired Focus Deltas

| Baseline | EM delta | EM 95% CI | F1 delta | F1 95% CI | Evidence-use delta | Evidence-use 95% CI |
|---|---:|---:|---:|---:|---:|---:|
| OracleMem writer + dense minus Full raw-store dense retrieval | +0.0095 | [-0.0190, +0.0379] | +0.0684 | [+0.0305, +0.1073] | +0.1232 | [+0.0521, +0.1896] |
| OracleMem writer + dense minus Budgeted raw replay + dense retrieval | +0.0427 | [+0.0142, +0.0758] | +0.2558 | [+0.2148, +0.2979] | +0.6114 | [+0.5403, +0.6777] |
| OracleMem writer + dense minus FIFO raw replay | +0.0332 | [+0.0047, +0.0616] | +0.2298 | [+0.1872, +0.2711] | +0.5640 | [+0.4882, +0.6398] |

## Diagnostic Interpretation

- Method names are hidden from the reader prompt; the prompt contains only the question and memory context.
- `INSUFFICIENT_EVIDENCE` is reported as an insufficient-evidence output rate, not as abstention accuracy.
- Old-answer/stale-answer rates require identifiable superseded-answer labels and are not reported here.
- This run is not main answer-accuracy evidence: OracleMem's raw EM gain over full raw-store dense retrieval is small and its paired CI crosses zero.
- The safe claim is limited to a frozen-context diagnostic: OracleMem improves token F1 and evidence-use over full raw-store dense retrieval while using shorter contexts.
