# Mem0 Written Store Rescoring

- Package: `llm_memory_validation\natural_adjudicated_100_gemini_flash\coverage_package`
- Written stores: `llm_memory_validation\mem0_natural200_actual\written_stores.jsonl`
- Coverage judge model: `google/gemini-2.5-flash`
- Salience model: `google/gemini-2.5-flash`
- Attempted instances: 87
- Completed instances: 87
- Skipped instances: 0
- Primary denominator: exact finite optimum over supplied package candidates plus Mem0-written memories (`package_plus_mem0_exact_opt`).
- Secondary package-candidate ratio is also reported and can exceed 1 for external Mem0 memories.

| Method | Budget | N | Ratio N | Mean ratio to union OPT | Mean ratio to package-candidate OPT | Mean written memories | Mean store cost |
|---|---:|---:|---:|---:|---:|---:|---:|
| actual_mem0_oracle_pruned_upper | 30 | 87 | 87 | 0.837 | 0.924 | 13.16 | 316.1 |
| actual_mem0_oracle_pruned_upper | 60 | 87 | 87 | 0.885 | 1.081 | 13.16 | 316.1 |
| actual_mem0_oracle_pruned_upper | 100 | 87 | 87 | 0.886 | 1.041 | 13.16 | 316.1 |
| actual_mem0_recency_pruned | 30 | 87 | 87 | 0.034 | 0.053 | 13.16 | 316.1 |
| actual_mem0_recency_pruned | 60 | 87 | 87 | 0.117 | 0.153 | 13.16 | 316.1 |
| actual_mem0_recency_pruned | 100 | 87 | 87 | 0.363 | 0.393 | 13.16 | 316.1 |
| actual_mem0_salience_pruned | 30 | 87 | 87 | 0.380 | 0.432 | 13.16 | 316.1 |
| actual_mem0_salience_pruned | 60 | 87 | 87 | 0.429 | 0.495 | 13.16 | 316.1 |
| actual_mem0_salience_pruned | 100 | 87 | 87 | 0.427 | 0.489 | 13.16 | 316.1 |

## Claim Boundary

`actual_mem0_salience_pruned` is a query-time Gemini Flash budget heuristic over Mem0-written memories. It is fairer than pure recency, but it is still not a native Mem0 write-time budget policy. `actual_mem0_oracle_pruned_upper` uses package coverage labels and is analysis-only. Ratios to package-candidate OPT are reference ratios, not approximation ratios, because external Mem0 memories are not part of the copied package candidate set.
