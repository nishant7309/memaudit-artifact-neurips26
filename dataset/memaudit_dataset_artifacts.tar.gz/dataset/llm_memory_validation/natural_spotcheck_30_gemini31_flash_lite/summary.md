# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.
- `policy_metadata`: Rows record estimated-policy, local proxy writer, validity-ablation, or candidate-quality-ablation provenance; train/dev estimated rows mark train-time oracle labels separately from dev-time visible-feature decisions and use no external services.
- `retrieval_summary`: Aggregated deterministic retrieval/write decomposition, emitted when --enable-retrieval is used.

## Local Proxy Writer Baselines

- `amac_admission`: proxy for A-MAC-style memory admission. Local proxy only: it does not run the published A-MAC policy, learned admission model, or task-specific reward estimator.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `unknown` | 30 | `amac_admission` | 29 | 0.1552 | 0.7241 [0.5517, 0.8966] | 22.72 | 0.00 | yes |
| `unknown` | 30 | `estimated_gvt` | 29 | 0.0862 | 0.6552 [0.4828, 0.8276] | 23.76 | 0.00 | yes |
| `unknown` | 30 | `fact_only` | 29 | 0.2414 | 0.7931 [0.6552, 0.9310] | 3.24 | 0.00 | yes |
| `unknown` | 30 | `opt` | 29 | 0.4310 | 1.0000 [1.0000, 1.0000] | 6.59 | 0.00 | yes |
| `unknown` | 30 | `oracle_gvt` | 29 | 0.4310 | 1.0000 [1.0000, 1.0000] | 6.59 | 0.00 | yes |
| `unknown` | 30 | `recency_raw` | 29 | 0.0000 | 0.5517 [0.3793, 0.7241] | 0.00 | 0.00 | yes |
| `unknown` | 30 | `summary_only` | 29 | 0.0345 | 0.5862 [0.4138, 0.7586] | 0.90 | 0.00 | yes |
| `unknown` | 60 | `amac_admission` | 29 | 0.1552 | 0.4828 [0.2759, 0.6724] | 31.24 | 0.00 | yes |
| `unknown` | 60 | `estimated_gvt` | 29 | 0.2759 | 0.6034 [0.4310, 0.7586] | 50.31 | 0.00 | yes |
| `unknown` | 60 | `fact_only` | 29 | 0.2414 | 0.5690 [0.3793, 0.7414] | 3.24 | 0.00 | yes |
| `unknown` | 60 | `opt` | 29 | 0.7241 | 1.0000 [1.0000, 1.0000] | 17.31 | 0.00 | yes |
| `unknown` | 60 | `oracle_gvt` | 29 | 0.7241 | 1.0000 [1.0000, 1.0000] | 17.31 | 0.00 | yes |
| `unknown` | 60 | `recency_raw` | 29 | 0.0000 | 0.3448 [0.1724, 0.5172] | 0.00 | 0.00 | yes |
| `unknown` | 60 | `summary_only` | 29 | 0.6034 | 0.8966 [0.7931, 0.9828] | 22.90 | 0.00 | yes |
| `unknown` | 100 | `amac_admission` | 29 | 0.1552 | 0.4828 [0.2759, 0.6724] | 31.90 | 0.00 | yes |
| `unknown` | 100 | `estimated_gvt` | 29 | 0.4483 | 0.7241 [0.5517, 0.8793] | 71.10 | 0.00 | yes |
| `unknown` | 100 | `fact_only` | 29 | 0.2414 | 0.5690 [0.3793, 0.7414] | 3.24 | 0.00 | yes |
| `unknown` | 100 | `opt` | 29 | 0.8103 | 1.0000 [1.0000, 1.0000] | 21.90 | 0.00 | yes |
| `unknown` | 100 | `oracle_gvt` | 29 | 0.8103 | 1.0000 [1.0000, 1.0000] | 21.90 | 0.00 | yes |
| `unknown` | 100 | `recency_raw` | 29 | 0.0000 | 0.3448 [0.1724, 0.5172] | 0.00 | 0.00 | yes |
| `unknown` | 100 | `summary_only` | 29 | 0.6724 | 0.8908 [0.7874, 0.9770] | 25.93 | 0.00 | yes |

## Best Method by Budget

- `unknown`, budget 30: `opt` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 60: `opt` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 100: `opt` with mean `ratio_to_opt=1.0000`.
