# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `abstention_hard` | 1 | `density_only` | 500 | 2.1479 | 0.9509 [0.9463, 0.9556] | 1.00 | 0.00 | yes |
| `abstention_hard` | 1 | `fact_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `abstention_hard` | 1 | `greedy` | 500 | 2.2598 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `abstention_hard` | 1 | `no_tombstone_gvt` | 500 | 2.2598 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `abstention_hard` | 1 | `no_tombstone_opt` | 500 | 2.2598 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `abstention_hard` | 1 | `opt` | 500 | 2.2598 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `abstention_hard` | 1 | `oracle_gvt` | 500 | 2.2598 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `abstention_hard` | 1 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `abstention_hard` | 1 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `abstention_hard` | 1 | `summary_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `abstention_hard` | 3 | `density_only` | 500 | 3.9753 | 0.6159 [0.6141, 0.6178] | 3.00 | 0.00 | yes |
| `abstention_hard` | 3 | `fact_only` | 500 | 1.8646 | 0.2890 [0.2879, 0.2901] | 2.00 | 0.00 | yes |
| `abstention_hard` | 3 | `greedy` | 500 | 6.4569 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `abstention_hard` | 3 | `no_tombstone_gvt` | 500 | 6.4569 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `abstention_hard` | 3 | `no_tombstone_opt` | 500 | 6.4569 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `abstention_hard` | 3 | `opt` | 500 | 6.4569 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `abstention_hard` | 3 | `oracle_gvt` | 500 | 6.4569 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `abstention_hard` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `abstention_hard` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `abstention_hard` | 3 | `summary_only` | 500 | 2.0989 | 0.3252 [0.3246, 0.3258] | 3.00 | 0.00 | yes |
| `abstention_hard` | 6 | `density_only` | 500 | 7.9530 | 0.9026 [0.9012, 0.9039] | 6.00 | 0.00 | yes |
| `abstention_hard` | 6 | `fact_only` | 500 | 3.7039 | 0.4205 [0.4194, 0.4215] | 6.00 | 0.00 | yes |
| `abstention_hard` | 6 | `greedy` | 500 | 8.5215 | 0.9670 [0.9668, 0.9672] | 6.00 | 0.00 | yes |
| `abstention_hard` | 6 | `no_tombstone_gvt` | 500 | 7.8655 | 0.8927 [0.8921, 0.8933] | 6.00 | 0.00 | yes |
| `abstention_hard` | 6 | `no_tombstone_opt` | 500 | 8.8121 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `abstention_hard` | 6 | `opt` | 500 | 8.8121 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `abstention_hard` | 6 | `oracle_gvt` | 500 | 7.8655 | 0.8927 [0.8921, 0.8933] | 6.00 | 0.00 | yes |
| `abstention_hard` | 6 | `recency_raw` | 500 | 2.8470 | 0.3231 [0.3221, 0.3241] | 4.00 | 0.00 | yes |
| `abstention_hard` | 6 | `reservoir_raw` | 500 | 2.7315 | 0.3100 [0.3076, 0.3122] | 4.00 | 0.00 | yes |
| `abstention_hard` | 6 | `summary_only` | 500 | 4.1264 | 0.4683 [0.4678, 0.4687] | 6.00 | 0.00 | yes |
| `abstention_hard` | 13 | `density_only` | 500 | 10.1108 | 0.8306 [0.8302, 0.8311] | 7.00 | 0.00 | yes |
| `abstention_hard` | 13 | `fact_only` | 500 | 3.8039 | 0.3125 [0.3119, 0.3131] | 10.00 | 0.00 | yes |
| `abstention_hard` | 13 | `greedy` | 500 | 10.1108 | 0.8306 [0.8302, 0.8311] | 7.00 | 0.00 | yes |
| `abstention_hard` | 13 | `no_tombstone_gvt` | 500 | 11.7052 | 0.9617 [0.9611, 0.9623] | 11.70 | 0.00 | yes |
| `abstention_hard` | 13 | `no_tombstone_opt` | 500 | 12.1714 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `abstention_hard` | 13 | `opt` | 500 | 12.1714 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `abstention_hard` | 13 | `oracle_gvt` | 500 | 11.7052 | 0.9617 [0.9611, 0.9623] | 11.70 | 0.00 | yes |
| `abstention_hard` | 13 | `recency_raw` | 500 | 8.0646 | 0.6626 [0.6618, 0.6634] | 12.00 | 0.00 | yes |
| `abstention_hard` | 13 | `reservoir_raw` | 500 | 7.9485 | 0.6530 [0.6504, 0.6559] | 12.00 | 0.00 | yes |
| `abstention_hard` | 13 | `summary_only` | 500 | 7.9254 | 0.6512 [0.6508, 0.6515] | 12.00 | 0.00 | yes |
| `base` | 1 | `density_only` | 500 | 2.2610 | 0.9548 [0.9486, 0.9607] | 1.00 | 1.00 | yes |
| `base` | 1 | `fact_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 1 | `greedy` | 500 | 2.3705 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `base` | 1 | `no_tombstone_gvt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 1 | `no_tombstone_opt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 1 | `opt` | 500 | 2.3705 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `base` | 1 | `oracle_gvt` | 500 | 2.3705 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `base` | 1 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 1 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 1 | `summary_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 3 | `density_only` | 500 | 3.4478 | 0.7262 [0.7214, 0.7308] | 3.00 | 1.00 | yes |
| `base` | 3 | `fact_only` | 500 | 2.3525 | 0.4952 [0.4923, 0.4978] | 2.00 | 0.00 | yes |
| `base` | 3 | `greedy` | 500 | 4.5205 | 0.9513 [0.9478, 0.9550] | 2.00 | 2.00 | yes |
| `base` | 3 | `no_tombstone_gvt` | 500 | 2.3525 | 0.4952 [0.4923, 0.4978] | 2.00 | 0.00 | yes |
| `base` | 3 | `no_tombstone_opt` | 500 | 2.3525 | 0.4952 [0.4923, 0.4978] | 2.00 | 0.00 | yes |
| `base` | 3 | `opt` | 500 | 4.7530 | 1.0000 [1.0000, 1.0000] | 2.64 | 1.36 | yes |
| `base` | 3 | `oracle_gvt` | 500 | 4.6220 | 0.9726 [0.9695, 0.9757] | 2.31 | 1.69 | yes |
| `base` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `base` | 3 | `summary_only` | 500 | 1.1038 | 0.2328 [0.2310, 0.2346] | 3.00 | 0.00 | yes |
| `base` | 6 | `density_only` | 500 | 3.5804 | 0.3982 [0.3948, 0.4013] | 6.00 | 0.00 | yes |
| `base` | 6 | `fact_only` | 500 | 5.8168 | 0.6458 [0.6433, 0.6479] | 6.00 | 0.00 | yes |
| `base` | 6 | `greedy` | 500 | 7.0413 | 0.7821 [0.7787, 0.7853] | 6.00 | 2.00 | yes |
| `base` | 6 | `no_tombstone_gvt` | 500 | 5.6909 | 0.6316 [0.6302, 0.6329] | 6.00 | 0.75 | yes |
| `base` | 6 | `no_tombstone_opt` | 500 | 5.8517 | 0.6497 [0.6475, 0.6515] | 6.00 | 0.19 | yes |
| `base` | 6 | `opt` | 500 | 9.0105 | 1.0000 [1.0000, 1.0000] | 6.00 | 2.00 | yes |
| `base` | 6 | `oracle_gvt` | 500 | 9.0105 | 1.0000 [1.0000, 1.0000] | 6.00 | 2.00 | yes |
| `base` | 6 | `recency_raw` | 500 | 3.2923 | 0.3654 [0.3637, 0.3671] | 6.00 | 0.45 | yes |
| `base` | 6 | `reservoir_raw` | 500 | 1.6441 | 0.1828 [0.1696, 0.1952] | 5.19 | 0.16 | yes |
| `base` | 6 | `summary_only` | 500 | 3.5115 | 0.3898 [0.3889, 0.3907] | 4.00 | 0.75 | yes |
| `base` | 13 | `density_only` | 500 | 8.4009 | 0.6672 [0.6655, 0.6690] | 12.00 | 2.00 | yes |
| `base` | 13 | `fact_only` | 500 | 8.2204 | 0.6529 [0.6511, 0.6543] | 12.00 | 0.00 | yes |
| `base` | 13 | `greedy` | 500 | 8.4009 | 0.6672 [0.6655, 0.6690] | 12.00 | 2.00 | yes |
| `base` | 13 | `no_tombstone_gvt` | 500 | 9.2775 | 0.7367 [0.7348, 0.7383] | 11.99 | 1.09 | yes |
| `base` | 13 | `no_tombstone_opt` | 500 | 9.3765 | 0.7447 [0.7441, 0.7453] | 12.00 | 1.14 | yes |
| `base` | 13 | `opt` | 500 | 12.5909 | 1.0000 [1.0000, 1.0000] | 12.00 | 2.00 | yes |
| `base` | 13 | `oracle_gvt` | 500 | 12.5909 | 1.0000 [1.0000, 1.0000] | 12.00 | 2.00 | yes |
| `base` | 13 | `recency_raw` | 500 | 3.4123 | 0.2711 [0.2698, 0.2724] | 10.00 | 0.45 | yes |
| `base` | 13 | `reservoir_raw` | 500 | 3.2553 | 0.2585 [0.2501, 0.2671] | 10.91 | 0.30 | yes |
| `base` | 13 | `summary_only` | 500 | 7.8916 | 0.6269 [0.6259, 0.6278] | 11.00 | 1.50 | yes |
| `density_trap` | 1 | `density_only` | 500 | 1.2903 | 0.9954 [0.9950, 0.9958] | 1.00 | 0.00 | yes |
| `density_trap` | 1 | `fact_only` | 500 | 1.2964 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `density_trap` | 1 | `greedy` | 500 | 1.2964 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `density_trap` | 1 | `no_tombstone_gvt` | 500 | 1.2964 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `density_trap` | 1 | `no_tombstone_opt` | 500 | 1.2964 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `density_trap` | 1 | `opt` | 500 | 1.2964 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `density_trap` | 1 | `oracle_gvt` | 500 | 1.2964 | 1.0000 [1.0000, 1.0000] | 1.00 | 0.00 | yes |
| `density_trap` | 1 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `density_trap` | 1 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `density_trap` | 1 | `summary_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `density_trap` | 3 | `density_only` | 500 | 2.4405 | 0.8081 [0.8068, 0.8095] | 3.00 | 0.00 | yes |
| `density_trap` | 3 | `fact_only` | 500 | 2.4506 | 0.8114 [0.8103, 0.8127] | 3.00 | 0.00 | yes |
| `density_trap` | 3 | `greedy` | 500 | 2.4506 | 0.8114 [0.8103, 0.8127] | 3.00 | 0.00 | yes |
| `density_trap` | 3 | `no_tombstone_gvt` | 500 | 2.9536 | 0.9777 [0.9749, 0.9806] | 3.00 | 0.00 | yes |
| `density_trap` | 3 | `no_tombstone_opt` | 500 | 3.0211 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `density_trap` | 3 | `opt` | 500 | 3.0211 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `density_trap` | 3 | `oracle_gvt` | 500 | 2.9536 | 0.9777 [0.9749, 0.9806] | 3.00 | 0.00 | yes |
| `density_trap` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `density_trap` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `density_trap` | 3 | `summary_only` | 500 | 1.8640 | 0.6170 [0.6169, 0.6171] | 3.00 | 0.00 | yes |
| `density_trap` | 6 | `density_only` | 500 | 5.5601 | 0.9651 [0.9629, 0.9674] | 6.00 | 0.00 | yes |
| `density_trap` | 6 | `fact_only` | 500 | 5.5040 | 0.9553 [0.9531, 0.9574] | 6.00 | 0.00 | yes |
| `density_trap` | 6 | `greedy` | 500 | 5.5040 | 0.9553 [0.9531, 0.9574] | 6.00 | 0.00 | yes |
| `density_trap` | 6 | `no_tombstone_gvt` | 500 | 5.6050 | 0.9721 [0.9669, 0.9769] | 6.00 | 0.00 | yes |
| `density_trap` | 6 | `no_tombstone_opt` | 500 | 5.7622 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `density_trap` | 6 | `opt` | 500 | 5.7622 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `density_trap` | 6 | `oracle_gvt` | 500 | 5.6050 | 0.9721 [0.9669, 0.9769] | 6.00 | 0.00 | yes |
| `density_trap` | 6 | `recency_raw` | 500 | 2.1079 | 0.3658 [0.3641, 0.3676] | 4.00 | 0.00 | yes |
| `density_trap` | 6 | `reservoir_raw` | 500 | 2.1058 | 0.3655 [0.3637, 0.3672] | 4.00 | 0.00 | yes |
| `density_trap` | 6 | `summary_only` | 500 | 3.6938 | 0.6410 [0.6409, 0.6411] | 6.00 | 0.00 | yes |
| `density_trap` | 13 | `density_only` | 500 | 7.1580 | 0.8096 [0.8082, 0.8111] | 8.00 | 0.00 | yes |
| `density_trap` | 13 | `fact_only` | 500 | 6.9699 | 0.7883 [0.7874, 0.7893] | 8.00 | 0.00 | yes |
| `density_trap` | 13 | `greedy` | 500 | 6.9699 | 0.7883 [0.7874, 0.7893] | 8.00 | 0.00 | yes |
| `density_trap` | 13 | `no_tombstone_gvt` | 500 | 8.4678 | 0.9576 [0.9559, 0.9591] | 12.68 | 0.00 | yes |
| `density_trap` | 13 | `no_tombstone_opt` | 500 | 8.8428 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `density_trap` | 13 | `opt` | 500 | 8.8428 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `density_trap` | 13 | `oracle_gvt` | 500 | 8.4678 | 0.9576 [0.9559, 0.9591] | 12.68 | 0.00 | yes |
| `density_trap` | 13 | `recency_raw` | 500 | 6.2676 | 0.7089 [0.7075, 0.7104] | 12.00 | 0.00 | yes |
| `density_trap` | 13 | `reservoir_raw` | 500 | 6.2669 | 0.7088 [0.7074, 0.7103] | 12.00 | 0.00 | yes |
| `density_trap` | 13 | `summary_only` | 500 | 7.1974 | 0.8140 [0.8137, 0.8144] | 12.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `density_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `fact_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `greedy` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `no_tombstone_gvt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `no_tombstone_opt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `opt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `oracle_gvt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `recency_raw` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `reservoir_raw` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 1 | `summary_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `density_only` | 500 | 2.0400 | 0.8047 [0.8035, 0.8061] | 2.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `fact_only` | 500 | 2.0400 | 0.8047 [0.8035, 0.8061] | 2.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `greedy` | 500 | 2.0400 | 0.8047 [0.8035, 0.8061] | 2.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `no_tombstone_gvt` | 500 | 2.4295 | 0.9582 [0.9548, 0.9614] | 3.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `no_tombstone_opt` | 500 | 2.5358 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `opt` | 500 | 2.5358 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `oracle_gvt` | 500 | 2.4295 | 0.9582 [0.9548, 0.9614] | 3.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `redundancy_heavy` | 3 | `summary_only` | 500 | 2.5358 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `density_only` | 500 | 4.3358 | 0.8640 [0.8613, 0.8662] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `fact_only` | 500 | 4.4972 | 0.8961 [0.8945, 0.8975] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `greedy` | 500 | 4.4972 | 0.8961 [0.8945, 0.8975] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `no_tombstone_gvt` | 500 | 4.9298 | 0.9824 [0.9806, 0.9843] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `no_tombstone_opt` | 500 | 5.0186 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `opt` | 500 | 5.0186 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `oracle_gvt` | 500 | 4.9298 | 0.9824 [0.9806, 0.9843] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `recency_raw` | 500 | 3.6673 | 0.7310 [0.7289, 0.7332] | 4.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `reservoir_raw` | 500 | 3.6655 | 0.7306 [0.7287, 0.7327] | 4.00 | 0.00 | yes |
| `redundancy_heavy` | 6 | `summary_only` | 500 | 4.5489 | 0.9065 [0.9062, 0.9067] | 6.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `density_only` | 500 | 6.6343 | 0.8035 [0.8023, 0.8046] | 10.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `fact_only` | 500 | 6.6301 | 0.8029 [0.8018, 0.8040] | 10.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `greedy` | 500 | 6.6301 | 0.8029 [0.8018, 0.8040] | 10.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `no_tombstone_gvt` | 500 | 8.2574 | 1.0000 [1.0000, 1.0000] | 12.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `no_tombstone_opt` | 500 | 8.2574 | 1.0000 [1.0000, 1.0000] | 12.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `opt` | 500 | 8.2574 | 1.0000 [1.0000, 1.0000] | 12.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `oracle_gvt` | 500 | 8.2574 | 1.0000 [1.0000, 1.0000] | 12.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `recency_raw` | 500 | 6.2052 | 0.7517 [0.7501, 0.7532] | 12.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `reservoir_raw` | 500 | 6.2085 | 0.7520 [0.7506, 0.7535] | 12.00 | 0.00 | yes |
| `redundancy_heavy` | 13 | `summary_only` | 500 | 6.4724 | 0.7839 [0.7835, 0.7843] | 12.00 | 0.00 | yes |
| `scope_shift` | 1 | `density_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `fact_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `greedy` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `no_tombstone_gvt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `no_tombstone_opt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `opt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `oracle_gvt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `recency_raw` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `reservoir_raw` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 1 | `summary_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 3 | `density_only` | 500 | 1.8020 | 0.9195 [0.9126, 0.9270] | 2.00 | 0.00 | yes |
| `scope_shift` | 3 | `fact_only` | 500 | 1.9608 | 0.9998 [0.9995, 1.0000] | 2.00 | 0.00 | yes |
| `scope_shift` | 3 | `greedy` | 500 | 1.9608 | 0.9998 [0.9995, 1.0000] | 2.00 | 0.00 | yes |
| `scope_shift` | 3 | `no_tombstone_gvt` | 500 | 1.9612 | 1.0000 [1.0000, 1.0000] | 2.01 | 0.00 | yes |
| `scope_shift` | 3 | `no_tombstone_opt` | 500 | 1.9612 | 1.0000 [1.0000, 1.0000] | 2.01 | 0.00 | yes |
| `scope_shift` | 3 | `opt` | 500 | 1.9612 | 1.0000 [1.0000, 1.0000] | 2.01 | 0.00 | yes |
| `scope_shift` | 3 | `oracle_gvt` | 500 | 1.9612 | 1.0000 [1.0000, 1.0000] | 2.01 | 0.00 | yes |
| `scope_shift` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `scope_shift` | 3 | `summary_only` | 500 | 1.9106 | 0.9746 [0.9738, 0.9755] | 3.00 | 0.00 | yes |
| `scope_shift` | 6 | `density_only` | 500 | 5.4136 | 0.9735 [0.9711, 0.9758] | 6.00 | 0.00 | yes |
| `scope_shift` | 6 | `fact_only` | 500 | 5.5628 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `scope_shift` | 6 | `greedy` | 500 | 5.4376 | 0.9775 [0.9736, 0.9813] | 6.00 | 0.00 | yes |
| `scope_shift` | 6 | `no_tombstone_gvt` | 500 | 5.5032 | 0.9891 [0.9870, 0.9910] | 6.00 | 0.00 | yes |
| `scope_shift` | 6 | `no_tombstone_opt` | 500 | 5.5628 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `scope_shift` | 6 | `opt` | 500 | 5.5628 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `scope_shift` | 6 | `oracle_gvt` | 500 | 5.5032 | 0.9891 [0.9870, 0.9910] | 6.00 | 0.00 | yes |
| `scope_shift` | 6 | `recency_raw` | 500 | 2.4068 | 0.4331 [0.4307, 0.4355] | 5.00 | 0.00 | yes |
| `scope_shift` | 6 | `reservoir_raw` | 500 | 2.4196 | 0.4354 [0.4330, 0.4376] | 5.00 | 0.00 | yes |
| `scope_shift` | 6 | `summary_only` | 500 | 4.7604 | 0.8566 [0.8551, 0.8580] | 6.00 | 0.00 | yes |
| `scope_shift` | 13 | `density_only` | 500 | 7.9704 | 0.9570 [0.9569, 0.9572] | 12.00 | 0.00 | yes |
| `scope_shift` | 13 | `fact_only` | 500 | 7.2004 | 0.8644 [0.8639, 0.8649] | 8.00 | 0.00 | yes |
| `scope_shift` | 13 | `greedy` | 500 | 7.9704 | 0.9570 [0.9569, 0.9572] | 12.00 | 0.00 | yes |
| `scope_shift` | 13 | `no_tombstone_gvt` | 500 | 7.6326 | 0.9170 [0.9139, 0.9200] | 11.13 | 0.00 | yes |
| `scope_shift` | 13 | `no_tombstone_opt` | 500 | 8.3279 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `scope_shift` | 13 | `opt` | 500 | 8.3279 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `scope_shift` | 13 | `oracle_gvt` | 500 | 7.6326 | 0.9170 [0.9139, 0.9200] | 11.13 | 0.00 | yes |
| `scope_shift` | 13 | `recency_raw` | 500 | 4.8296 | 0.5801 [0.5783, 0.5818] | 10.00 | 0.00 | yes |
| `scope_shift` | 13 | `reservoir_raw` | 500 | 4.8480 | 0.5823 [0.5806, 0.5839] | 10.00 | 0.00 | yes |
| `scope_shift` | 13 | `summary_only` | 500 | 8.0931 | 0.9719 [0.9714, 0.9723] | 13.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `density_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `fact_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `greedy` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `no_tombstone_gvt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `no_tombstone_opt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `opt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `oracle_gvt` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `recency_raw` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `reservoir_raw` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 1 | `summary_only` | 500 | 0.0000 | 1.0000 [1.0000, 1.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `density_only` | 500 | 1.5030 | 0.7145 [0.7096, 0.7193] | 2.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `fact_only` | 500 | 1.6293 | 0.7744 [0.7727, 0.7758] | 2.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `greedy` | 500 | 1.6293 | 0.7744 [0.7727, 0.7758] | 2.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `no_tombstone_gvt` | 500 | 2.0368 | 0.9683 [0.9652, 0.9712] | 3.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `no_tombstone_opt` | 500 | 2.1039 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `opt` | 500 | 2.1039 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `oracle_gvt` | 500 | 2.0368 | 0.9683 [0.9652, 0.9712] | 3.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `summary_tradeoff` | 3 | `summary_only` | 500 | 2.1039 | 1.0000 [1.0000, 1.0000] | 3.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `density_only` | 500 | 4.5045 | 0.9574 [0.9546, 0.9601] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `fact_only` | 500 | 4.7070 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `greedy` | 500 | 4.7070 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `no_tombstone_gvt` | 500 | 4.6362 | 0.9845 [0.9818, 0.9870] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `no_tombstone_opt` | 500 | 4.7070 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `opt` | 500 | 4.7070 | 1.0000 [1.0000, 1.0000] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `oracle_gvt` | 500 | 4.6362 | 0.9845 [0.9818, 0.9870] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `recency_raw` | 500 | 2.8430 | 0.6046 [0.6020, 0.6074] | 5.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `reservoir_raw` | 500 | 2.8548 | 0.6071 [0.6044, 0.6099] | 5.00 | 0.00 | yes |
| `summary_tradeoff` | 6 | `summary_only` | 500 | 4.1517 | 0.8829 [0.8809, 0.8850] | 6.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `density_only` | 500 | 7.5060 | 0.8276 [0.8266, 0.8286] | 10.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `fact_only` | 500 | 7.5060 | 0.8276 [0.8266, 0.8286] | 10.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `greedy` | 500 | 7.5060 | 0.8276 [0.8266, 0.8286] | 10.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `no_tombstone_gvt` | 500 | 8.8847 | 0.9799 [0.9779, 0.9819] | 12.93 | 0.00 | yes |
| `summary_tradeoff` | 13 | `no_tombstone_opt` | 500 | 9.0669 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `opt` | 500 | 9.0669 | 1.0000 [1.0000, 1.0000] | 13.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `oracle_gvt` | 500 | 8.8847 | 0.9799 [0.9779, 0.9819] | 12.93 | 0.00 | yes |
| `summary_tradeoff` | 13 | `recency_raw` | 500 | 5.6975 | 0.6285 [0.6270, 0.6299] | 10.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `reservoir_raw` | 500 | 5.7027 | 0.6290 [0.6274, 0.6306] | 10.00 | 0.00 | yes |
| `summary_tradeoff` | 13 | `summary_only` | 500 | 8.0870 | 0.8920 [0.8914, 0.8926] | 12.00 | 0.00 | yes |
| `temporal_interval` | 1 | `density_only` | 500 | 1.6000 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `temporal_interval` | 1 | `fact_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 1 | `greedy` | 500 | 1.6000 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `temporal_interval` | 1 | `no_tombstone_gvt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 1 | `no_tombstone_opt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 1 | `opt` | 500 | 1.6000 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `temporal_interval` | 1 | `oracle_gvt` | 500 | 1.6000 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `temporal_interval` | 1 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 1 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 1 | `summary_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 3 | `density_only` | 500 | 2.9250 | 0.9141 [0.9141, 0.9141] | 3.00 | 1.00 | yes |
| `temporal_interval` | 3 | `fact_only` | 500 | 1.4000 | 0.4375 [0.4375, 0.4375] | 2.00 | 0.00 | yes |
| `temporal_interval` | 3 | `greedy` | 500 | 3.2000 | 1.0000 [1.0000, 1.0000] | 2.00 | 2.00 | yes |
| `temporal_interval` | 3 | `no_tombstone_gvt` | 500 | 2.1000 | 0.6562 [0.6562, 0.6562] | 3.00 | 0.70 | yes |
| `temporal_interval` | 3 | `no_tombstone_opt` | 500 | 2.1000 | 0.6562 [0.6562, 0.6562] | 3.00 | 0.70 | yes |
| `temporal_interval` | 3 | `opt` | 500 | 3.2000 | 1.0000 [1.0000, 1.0000] | 2.00 | 2.00 | yes |
| `temporal_interval` | 3 | `oracle_gvt` | 500 | 3.2000 | 1.0000 [1.0000, 1.0000] | 2.00 | 2.00 | yes |
| `temporal_interval` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `temporal_interval` | 3 | `summary_only` | 500 | 2.1000 | 0.6562 [0.6562, 0.6562] | 3.00 | 0.70 | yes |
| `temporal_interval` | 6 | `density_only` | 500 | 3.9750 | 0.6625 [0.6625, 0.6625] | 6.00 | 0.00 | yes |
| `temporal_interval` | 6 | `fact_only` | 500 | 3.7000 | 0.6167 [0.6167, 0.6167] | 6.00 | 0.00 | yes |
| `temporal_interval` | 6 | `greedy` | 500 | 5.8500 | 0.9750 [0.9750, 0.9750] | 6.00 | 2.00 | yes |
| `temporal_interval` | 6 | `no_tombstone_gvt` | 500 | 4.2000 | 0.7000 [0.7000, 0.7000] | 6.00 | 1.40 | yes |
| `temporal_interval` | 6 | `no_tombstone_opt` | 500 | 4.2000 | 0.7000 [0.7000, 0.7000] | 6.00 | 1.40 | yes |
| `temporal_interval` | 6 | `opt` | 500 | 6.0000 | 1.0000 [1.0000, 1.0000] | 6.00 | 2.00 | yes |
| `temporal_interval` | 6 | `oracle_gvt` | 500 | 6.0000 | 1.0000 [1.0000, 1.0000] | 6.00 | 2.00 | yes |
| `temporal_interval` | 6 | `recency_raw` | 500 | 2.1350 | 0.3558 [0.3558, 0.3558] | 5.00 | 0.45 | yes |
| `temporal_interval` | 6 | `reservoir_raw` | 500 | 2.8579 | 0.4763 [0.4705, 0.4821] | 5.00 | 0.09 | yes |
| `temporal_interval` | 6 | `summary_only` | 500 | 4.2000 | 0.7000 [0.7000, 0.7000] | 6.00 | 1.40 | yes |
| `temporal_interval` | 13 | `density_only` | 500 | 9.8250 | 0.9238 [0.9238, 0.9238] | 12.00 | 2.00 | yes |
| `temporal_interval` | 13 | `fact_only` | 500 | 6.4000 | 0.6018 [0.6018, 0.6018] | 12.00 | 0.00 | yes |
| `temporal_interval` | 13 | `greedy` | 500 | 9.8250 | 0.9238 [0.9238, 0.9238] | 12.00 | 2.00 | yes |
| `temporal_interval` | 13 | `no_tombstone_gvt` | 500 | 8.7250 | 0.8204 [0.8204, 0.8204] | 13.00 | 0.70 | yes |
| `temporal_interval` | 13 | `no_tombstone_opt` | 500 | 8.8350 | 0.8307 [0.8307, 0.8307] | 13.00 | 1.40 | yes |
| `temporal_interval` | 13 | `opt` | 500 | 10.6350 | 1.0000 [1.0000, 1.0000] | 13.00 | 2.00 | yes |
| `temporal_interval` | 13 | `oracle_gvt` | 500 | 9.6250 | 0.9050 [0.9050, 0.9050] | 13.00 | 1.00 | yes |
| `temporal_interval` | 13 | `recency_raw` | 500 | 4.2700 | 0.4015 [0.4015, 0.4015] | 10.00 | 0.90 | yes |
| `temporal_interval` | 13 | `reservoir_raw` | 500 | 5.5748 | 0.5242 [0.5202, 0.5280] | 10.00 | 0.26 | yes |
| `temporal_interval` | 13 | `summary_only` | 500 | 8.1750 | 0.7687 [0.7687, 0.7687] | 12.00 | 1.40 | yes |
| `update_chain` | 1 | `density_only` | 500 | 1.8500 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `update_chain` | 1 | `fact_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 1 | `greedy` | 500 | 1.8500 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `update_chain` | 1 | `no_tombstone_gvt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 1 | `no_tombstone_opt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 1 | `opt` | 500 | 1.8500 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `update_chain` | 1 | `oracle_gvt` | 500 | 1.8500 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `update_chain` | 1 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 1 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 1 | `summary_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 3 | `density_only` | 500 | 1.9500 | 0.3514 [0.3514, 0.3514] | 3.00 | 1.00 | yes |
| `update_chain` | 3 | `fact_only` | 500 | 2.3000 | 0.4144 [0.4144, 0.4144] | 2.00 | 0.00 | yes |
| `update_chain` | 3 | `greedy` | 500 | 5.5500 | 1.0000 [1.0000, 1.0000] | 3.00 | 3.00 | yes |
| `update_chain` | 3 | `no_tombstone_gvt` | 500 | 2.6975 | 0.4860 [0.4860, 0.4860] | 3.00 | 0.65 | yes |
| `update_chain` | 3 | `no_tombstone_opt` | 500 | 2.6975 | 0.4860 [0.4860, 0.4860] | 3.00 | 0.65 | yes |
| `update_chain` | 3 | `opt` | 500 | 5.5500 | 1.0000 [1.0000, 1.0000] | 3.00 | 3.00 | yes |
| `update_chain` | 3 | `oracle_gvt` | 500 | 5.5500 | 1.0000 [1.0000, 1.0000] | 3.00 | 3.00 | yes |
| `update_chain` | 3 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 3 | `reservoir_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `update_chain` | 3 | `summary_only` | 500 | 2.6975 | 0.4860 [0.4860, 0.4860] | 3.00 | 0.65 | yes |
| `update_chain` | 6 | `density_only` | 500 | 5.6500 | 0.7304 [0.7304, 0.7304] | 5.00 | 3.00 | yes |
| `update_chain` | 6 | `fact_only` | 500 | 2.5000 | 0.3232 [0.3232, 0.3232] | 6.00 | 0.00 | yes |
| `update_chain` | 6 | `greedy` | 500 | 5.6500 | 0.7304 [0.7304, 0.7304] | 5.00 | 3.00 | yes |
| `update_chain` | 6 | `no_tombstone_gvt` | 500 | 2.9625 | 0.3830 [0.3830, 0.3830] | 5.00 | 0.35 | yes |
| `update_chain` | 6 | `no_tombstone_opt` | 500 | 3.9650 | 0.5126 [0.5126, 0.5126] | 6.00 | 1.30 | yes |
| `update_chain` | 6 | `opt` | 500 | 7.7350 | 1.0000 [1.0000, 1.0000] | 5.00 | 3.00 | yes |
| `update_chain` | 6 | `oracle_gvt` | 500 | 7.7350 | 1.0000 [1.0000, 1.0000] | 5.00 | 3.00 | yes |
| `update_chain` | 6 | `recency_raw` | 500 | 2.9625 | 0.3830 [0.3830, 0.3830] | 5.00 | 0.35 | yes |
| `update_chain` | 6 | `reservoir_raw` | 500 | 1.5081 | 0.1950 [0.1806, 0.2088] | 4.76 | 0.27 | yes |
| `update_chain` | 6 | `summary_only` | 500 | 3.9650 | 0.5126 [0.5126, 0.5126] | 6.00 | 1.30 | yes |
| `update_chain` | 13 | `density_only` | 500 | 5.6500 | 0.7040 [0.7040, 0.7040] | 5.00 | 3.00 | yes |
| `update_chain` | 13 | `fact_only` | 500 | 2.6000 | 0.3240 [0.3240, 0.3240] | 8.00 | 0.00 | yes |
| `update_chain` | 13 | `greedy` | 500 | 5.6500 | 0.7040 [0.7040, 0.7040] | 5.00 | 3.00 | yes |
| `update_chain` | 13 | `no_tombstone_gvt` | 500 | 5.5975 | 0.6975 [0.6975, 0.6975] | 13.00 | 1.65 | yes |
| `update_chain` | 13 | `no_tombstone_opt` | 500 | 5.5975 | 0.6975 [0.6975, 0.6975] | 13.00 | 1.65 | yes |
| `update_chain` | 13 | `opt` | 500 | 8.0250 | 1.0000 [1.0000, 1.0000] | 11.00 | 3.00 | yes |
| `update_chain` | 13 | `oracle_gvt` | 500 | 8.0250 | 1.0000 [1.0000, 1.0000] | 11.00 | 3.00 | yes |
| `update_chain` | 13 | `recency_raw` | 500 | 3.7100 | 0.4623 [0.4623, 0.4623] | 10.00 | 0.70 | yes |
| `update_chain` | 13 | `reservoir_raw` | 500 | 2.6807 | 0.3340 [0.3197, 0.3475] | 9.54 | 0.54 | yes |
| `update_chain` | 13 | `summary_only` | 500 | 5.3025 | 0.6607 [0.6607, 0.6607] | 12.00 | 1.95 | yes |

## Best Method by Budget

- `abstention_hard`, budget 1: `greedy` with mean `ratio_to_opt=1.0000`.
- `abstention_hard`, budget 3: `greedy` with mean `ratio_to_opt=1.0000`.
- `abstention_hard`, budget 6: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `abstention_hard`, budget 13: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `base`, budget 1: `greedy` with mean `ratio_to_opt=1.0000`.
- `base`, budget 3: `opt` with mean `ratio_to_opt=1.0000`.
- `base`, budget 6: `opt` with mean `ratio_to_opt=1.0000`.
- `base`, budget 13: `opt` with mean `ratio_to_opt=1.0000`.
- `density_trap`, budget 1: `fact_only` with mean `ratio_to_opt=1.0000`.
- `density_trap`, budget 3: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `density_trap`, budget 6: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `density_trap`, budget 13: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `redundancy_heavy`, budget 1: `density_only` with mean `ratio_to_opt=1.0000`.
- `redundancy_heavy`, budget 3: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `redundancy_heavy`, budget 6: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `redundancy_heavy`, budget 13: `no_tombstone_gvt` with mean `ratio_to_opt=1.0000`.
- `scope_shift`, budget 1: `density_only` with mean `ratio_to_opt=1.0000`.
- `scope_shift`, budget 3: `no_tombstone_gvt` with mean `ratio_to_opt=1.0000`.
- `scope_shift`, budget 6: `fact_only` with mean `ratio_to_opt=1.0000`.
- `scope_shift`, budget 13: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `summary_tradeoff`, budget 1: `density_only` with mean `ratio_to_opt=1.0000`.
- `summary_tradeoff`, budget 3: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `summary_tradeoff`, budget 6: `fact_only` with mean `ratio_to_opt=1.0000`.
- `summary_tradeoff`, budget 13: `no_tombstone_opt` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 1: `density_only` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 3: `greedy` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 6: `opt` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 13: `opt` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 1: `density_only` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 3: `greedy` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 6: `opt` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 13: `opt` with mean `ratio_to_opt=1.0000`.
