# Coverage-Package Writer Adapter Report

- Package: `llm_memory_validation\human_style_examples\coverage_package`
- Queries evaluated: 85
- Budgets: `150,300,600,1000`
- Denominator: exact package OPT over the finite coverage package.
- API calls: none.

## Claim Boundary

- These rows evaluate visible-metadata writer adapters under the same package denominator.
- `memgpt_tiered` is a Letta/MemGPT-style archival/recency adapter, not a Letta server run.
- `amem_graph` is an A-Mem-style graph/evolving-memory adapter, not the published A-Mem pipeline.
- Local reference repos present in this workspace: `external_repos/letta` and `external_repos/AgenticMemory`.

## Adapter Provenance

- `memgpt_tiered`: Letta/MemGPT-style archival/recency tiered memory.
  Decision features: representation type, serialized text, confidence, recency, novelty, and budget.
  Limitation: Faithful local adapter only: it does not run a Letta server, MemGPT's controller, paging loop, tool calls, summarizer, or retriever.
- `amem_graph`: A-Mem-style adaptive graph/evolving memory.
  Decision features: graph/summary/update type priors, text anchors, link overlap, novelty, recency, and budget.
  Limitation: Faithful local adapter only: it does not run A-Mem's learned memory evolution, LLM-generated relation expansion, or retrieval-time graph traversal.
- `mem0_extract`: Mem0-style extraction and consolidation.
  Decision features: compact fact/update candidates, duplicate penalties, confidence, novelty, and budget.
  Limitation: Local proxy only: it does not run Mem0's extraction model, vector store, graph store, or update pipeline.
- `amac_admission`: A-MAC-style memory admission.
  Decision features: estimated salience, confidence, novelty, recency, type prior, online admission, and eviction.
  Limitation: Local proxy only: it does not run the published A-MAC policy, learned admission model, or task-specific reward estimator.

## Mean Ratio To Exact Package OPT

| Method | B=150 | B=300 | B=600 | B=1000 |
| --- | --- | --- | --- | --- |
| `opt` | 1.000 | 1.000 | 1.000 | 1.000 |
| `oracle_gvt` | 1.000 | 1.000 | 1.000 | 1.000 |
| `memgpt_tiered` | 0.847 | 0.847 | 0.847 | 0.847 |
| `amem_graph` | 0.876 | 0.876 | 0.876 | 0.876 |
| `mem0_extract` | 0.753 | 0.753 | 0.753 | 0.753 |
| `amac_admission` | 0.835 | 0.835 | 0.835 | 0.835 |
| `estimated_gvt` | 0.994 | 0.994 | 0.994 | 0.994 |
| `density_only` | 1.000 | 1.000 | 1.000 | 1.000 |
| `summary_only` | 0.000 | 0.000 | 0.000 | 0.000 |
| `fact_only` | 0.059 | 0.059 | 0.059 | 0.059 |
| `recency_raw` | 0.000 | 0.000 | 0.000 | 0.000 |
