# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.
- `policy_metadata`: Rows record estimated-policy, local proxy writer, validity-ablation, or candidate-quality-ablation provenance; train/dev estimated rows mark train-time oracle labels separately from dev-time visible-feature decisions and use no external services.
- `retrieval_summary`: Aggregated deterministic retrieval/write decomposition, emitted when --enable-retrieval is used.

## Local Proxy Writer Baselines

- `amac_admission`: proxy for A-MAC-style memory admission. Local proxy only: it does not run the published A-MAC policy, learned admission model, or task-specific reward estimator.
- `amem_graph`: proxy for A-Mem-style adaptive graph/evolving memory. Faithful local adapter only: it does not run A-Mem's learned memory evolution, LLM-generated relation expansion, or retrieval-time graph traversal.
- `mem0_extract`: proxy for Mem0-style extraction and consolidation. Local proxy only: it does not run Mem0's extraction model, vector store, graph store, or update pipeline.
- `memgpt_tiered`: proxy for Letta/MemGPT-style archival/recency tiered memory. Faithful local adapter only: it does not run a Letta server, MemGPT's controller, paging loop, tool calls, summarizer, or retriever.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `unknown` | 150 | `amac_admission` | 85 | 0.8941 | 0.8353 [0.7529, 0.9118] | 15.25 | 0.00 | yes |
| `unknown` | 150 | `amem_graph` | 85 | 0.9412 | 0.8765 [0.7941, 0.9412] | 15.44 | 0.00 | yes |
| `unknown` | 150 | `density_only` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 150 | `estimated_gvt` | 85 | 1.0588 | 0.9941 [0.9824, 1.0000] | 17.21 | 0.00 | yes |
| `unknown` | 150 | `fact_only` | 85 | 0.0588 | 0.0588 [0.0118, 0.1059] | 1.08 | 0.00 | yes |
| `unknown` | 150 | `mem0_extract` | 85 | 0.8118 | 0.7529 [0.6588, 0.8412] | 15.14 | 0.00 | yes |
| `unknown` | 150 | `memgpt_tiered` | 85 | 0.9059 | 0.8471 [0.7647, 0.9176] | 15.46 | 0.00 | yes |
| `unknown` | 150 | `opt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 150 | `oracle_gvt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 150 | `recency_raw` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 150 | `summary_only` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 300 | `amac_admission` | 85 | 0.8941 | 0.8353 [0.7529, 0.9118] | 15.25 | 0.00 | yes |
| `unknown` | 300 | `amem_graph` | 85 | 0.9412 | 0.8765 [0.7941, 0.9412] | 15.44 | 0.00 | yes |
| `unknown` | 300 | `density_only` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 300 | `estimated_gvt` | 85 | 1.0588 | 0.9941 [0.9824, 1.0000] | 17.21 | 0.00 | yes |
| `unknown` | 300 | `fact_only` | 85 | 0.0588 | 0.0588 [0.0118, 0.1059] | 1.08 | 0.00 | yes |
| `unknown` | 300 | `mem0_extract` | 85 | 0.8118 | 0.7529 [0.6588, 0.8412] | 15.14 | 0.00 | yes |
| `unknown` | 300 | `memgpt_tiered` | 85 | 0.9059 | 0.8471 [0.7647, 0.9176] | 15.46 | 0.00 | yes |
| `unknown` | 300 | `opt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 300 | `oracle_gvt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 300 | `recency_raw` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 300 | `summary_only` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 600 | `amac_admission` | 85 | 0.8941 | 0.8353 [0.7529, 0.9118] | 15.25 | 0.00 | yes |
| `unknown` | 600 | `amem_graph` | 85 | 0.9412 | 0.8765 [0.7941, 0.9412] | 15.44 | 0.00 | yes |
| `unknown` | 600 | `density_only` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 600 | `estimated_gvt` | 85 | 1.0588 | 0.9941 [0.9824, 1.0000] | 17.21 | 0.00 | yes |
| `unknown` | 600 | `fact_only` | 85 | 0.0588 | 0.0588 [0.0118, 0.1059] | 1.08 | 0.00 | yes |
| `unknown` | 600 | `mem0_extract` | 85 | 0.8118 | 0.7529 [0.6588, 0.8412] | 15.14 | 0.00 | yes |
| `unknown` | 600 | `memgpt_tiered` | 85 | 0.9059 | 0.8471 [0.7647, 0.9176] | 15.46 | 0.00 | yes |
| `unknown` | 600 | `opt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 600 | `oracle_gvt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 600 | `recency_raw` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 600 | `summary_only` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 1000 | `amac_admission` | 85 | 0.8941 | 0.8353 [0.7529, 0.9118] | 15.25 | 0.00 | yes |
| `unknown` | 1000 | `amem_graph` | 85 | 0.9412 | 0.8765 [0.7941, 0.9412] | 15.44 | 0.00 | yes |
| `unknown` | 1000 | `density_only` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 1000 | `estimated_gvt` | 85 | 1.0588 | 0.9941 [0.9824, 1.0000] | 17.21 | 0.00 | yes |
| `unknown` | 1000 | `fact_only` | 85 | 0.0588 | 0.0588 [0.0118, 0.1059] | 1.08 | 0.00 | yes |
| `unknown` | 1000 | `mem0_extract` | 85 | 0.8118 | 0.7529 [0.6588, 0.8412] | 15.14 | 0.00 | yes |
| `unknown` | 1000 | `memgpt_tiered` | 85 | 0.9059 | 0.8471 [0.7647, 0.9176] | 15.46 | 0.00 | yes |
| `unknown` | 1000 | `opt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 1000 | `oracle_gvt` | 85 | 1.0706 | 1.0000 [1.0000, 1.0000] | 16.40 | 0.00 | yes |
| `unknown` | 1000 | `recency_raw` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `unknown` | 1000 | `summary_only` | 85 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |

## Best Method by Budget

- `unknown`, budget 150: `density_only` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 300: `density_only` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 600: `density_only` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 1000: `density_only` with mean `ratio_to_opt=1.0000`.
