# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.
- `retrieval_summary`: Aggregated deterministic retrieval/write decomposition, emitted when --enable-retrieval is used.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `base` | 1 | `opt` | 100 | 2.3800 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `base` | 4 | `opt` | 100 | 6.8750 | 1.0000 [1.0000, 1.0000] | 4.00 | 2.00 | yes |
| `base` | 7 | `opt` | 100 | 9.0100 | 1.0000 [1.0000, 1.0000] | 6.00 | 2.00 | yes |
| `base` | 15 | `opt` | 100 | 12.7360 | 1.0000 [1.0000, 1.0000] | 14.00 | 2.00 | yes |
| `temporal_interval` | 1 | `opt` | 100 | 1.6000 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `temporal_interval` | 4 | `opt` | 100 | 4.6000 | 1.0000 [1.0000, 1.0000] | 4.00 | 2.00 | yes |
| `temporal_interval` | 7 | `opt` | 100 | 6.5850 | 1.0000 [1.0000, 1.0000] | 7.00 | 2.00 | yes |
| `temporal_interval` | 15 | `opt` | 100 | 11.9600 | 1.0000 [1.0000, 1.0000] | 15.00 | 2.00 | yes |
| `update_chain` | 1 | `opt` | 100 | 1.8500 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| `update_chain` | 4 | `opt` | 100 | 6.0000 | 1.0000 [1.0000, 1.0000] | 4.00 | 2.00 | yes |
| `update_chain` | 7 | `opt` | 100 | 7.8350 | 1.0000 [1.0000, 1.0000] | 7.00 | 3.00 | yes |
| `update_chain` | 15 | `opt` | 100 | 8.0250 | 1.0000 [1.0000, 1.0000] | 11.00 | 3.00 | yes |

## Best Method by Budget

- `base`, budget 1: `opt` with mean `ratio_to_opt=1.0000`.
- `base`, budget 4: `opt` with mean `ratio_to_opt=1.0000`.
- `base`, budget 7: `opt` with mean `ratio_to_opt=1.0000`.
- `base`, budget 15: `opt` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 1: `opt` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 4: `opt` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 7: `opt` with mean `ratio_to_opt=1.0000`.
- `temporal_interval`, budget 15: `opt` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 1: `opt` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 4: `opt` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 7: `opt` with mean `ratio_to_opt=1.0000`.
- `update_chain`, budget 15: `opt` with mean `ratio_to_opt=1.0000`.
