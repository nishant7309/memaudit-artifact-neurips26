# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.
- `policy_metadata`: Rows record estimated-policy, local proxy writer, validity-ablation, or candidate-quality-ablation provenance; train/dev estimated rows mark train-time oracle labels separately from dev-time visible-feature decisions and use no external services.
- `retrieval_summary`: Aggregated deterministic retrieval/write decomposition, emitted when --enable-retrieval is used.

## Local Proxy Writer Baselines

- `amem_graph`: proxy for A-Mem-style adaptive graph/evolving memory. Faithful local adapter only: it does not run A-Mem's learned memory evolution, LLM-generated relation expansion, or retrieval-time graph traversal.
- `mem0_extract`: proxy for Mem0-style extraction and consolidation. Local proxy only: it does not run Mem0's extraction model, vector store, graph store, or update pipeline.
- `memgpt_tiered`: proxy for Letta/MemGPT-style archival/recency tiered memory. Faithful local adapter only: it does not run a Letta server, MemGPT's controller, paging loop, tool calls, summarizer, or retriever.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `unknown` | 30 | `amem_graph` | 81 | 0.4506 | 0.5000 [0.4043, 0.6019] | 20.57 | 0.00 | yes |
| `unknown` | 30 | `estimated_gvt` | 81 | 0.4691 | 0.5010 [0.4012, 0.6080] | 23.68 | 0.00 | yes |
| `unknown` | 30 | `mem0_extract` | 81 | 0.5556 | 0.5741 [0.4691, 0.6749] | 21.02 | 0.00 | yes |
| `unknown` | 30 | `memgpt_tiered` | 81 | 0.5802 | 0.6049 [0.5031, 0.7099] | 21.52 | 0.00 | yes |
| `unknown` | 30 | `oracle_gvt` | 81 | 0.9630 | 0.9938 [0.9753, 1.0000] | 15.84 | 0.00 | yes |
| `unknown` | 60 | `amem_graph` | 81 | 0.6358 | 0.4599 [0.3693, 0.5442] | 30.65 | 0.00 | yes |
| `unknown` | 60 | `estimated_gvt` | 81 | 0.9136 | 0.6759 [0.5916, 0.7644] | 49.93 | 0.00 | yes |
| `unknown` | 60 | `mem0_extract` | 81 | 0.6358 | 0.4609 [0.3652, 0.5504] | 28.15 | 0.00 | yes |
| `unknown` | 60 | `memgpt_tiered` | 81 | 0.6420 | 0.4650 [0.3714, 0.5556] | 28.42 | 0.00 | yes |
| `unknown` | 60 | `oracle_gvt` | 81 | 1.3642 | 0.9959 [0.9877, 1.0000] | 29.01 | 0.00 | yes |
| `unknown` | 100 | `amem_graph` | 81 | 0.6728 | 0.4558 [0.3663, 0.5391] | 32.07 | 0.00 | yes |
| `unknown` | 100 | `estimated_gvt` | 81 | 1.1420 | 0.8045 [0.7356, 0.8755] | 68.74 | 0.00 | yes |
| `unknown` | 100 | `mem0_extract` | 81 | 0.6543 | 0.4606 [0.3669, 0.5432] | 29.19 | 0.00 | yes |
| `unknown` | 100 | `memgpt_tiered` | 81 | 0.6605 | 0.4636 [0.3717, 0.5535] | 29.53 | 0.00 | yes |
| `unknown` | 100 | `oracle_gvt` | 81 | 1.4815 | 1.0000 [1.0000, 1.0000] | 34.10 | 0.00 | yes |

## Best Method by Budget

- `unknown`, budget 30: `oracle_gvt` with mean `ratio_to_opt=0.9938`.
- `unknown`, budget 60: `oracle_gvt` with mean `ratio_to_opt=0.9959`.
- `unknown`, budget 100: `oracle_gvt` with mean `ratio_to_opt=1.0000`.
