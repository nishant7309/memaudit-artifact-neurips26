﻿# MemAudit

MemAudit is an Exact Package-Oracle evaluation protocol for budgeted long-term LLM
memory writing. The core question is finite and package-conditional:

> Given a fixed storage budget and a finite semantic evidence package, how close
> is a written memory store to the best package-feasible store?

This repository contains the manuscript, exact-small synthetic benchmarks,
validity-heavy stress benchmarks, natural support-sliced coverage packages,
Mem0 diagnostic rescoring artifacts, and reproducibility scripts.

MemAudit is not a runtime memory product. It is an evaluation layer for
memory writers: it scores finite candidate packages, budgeted representation
choices, and external written stores against explicit denominators.

## Quickcheck

Run the deterministic tests:

```powershell
python -m unittest test_oraclemem.py
```

Run a tiny Exact Package-Oracle smoke benchmark:

```powershell
python run_oraclemem_mvp.py --n-seeds 3 --budgets 4 --distribution base --methods opt,oracle_gvt,density_only --out-dir oraclemem_runs/quickcheck
```

Expected smoke outputs:

- `oraclemem_runs/quickcheck/raw_results.jsonl`
- `oraclemem_runs/quickcheck/summary.json`
- `oraclemem_runs/quickcheck/summary.md`

## Main Artifacts

- `main.tex`: active manuscript.
- `references.bib`: bibliography.
- `figures/`: paper figure assets generated from cached experiment summaries.
- `oraclemem_runs/exact_500`: exact-small 500-instance sweep.
- `oraclemem_runs/stress_exact_500`: validity-heavy stress sweep.
- `oraclemem_runs/representative_writers_500`: non-oracle writer diagnostic sweep with Estimated-GVT and A-MAC-like admission.
- `llm_memory_validation/oraclemem_natural_200_gemini_v2`: Natural-200 support-sliced coverage package.
- `llm_memory_validation/natural_adjudicated_100_gemini_flash`: stricter adjudicated natural subset.
- `llm_memory_validation/natural_spotcheck_30_gemini31_flash_lite`: independent Gemini Flash-Lite adjudication spot-check.
- `llm_memory_validation/human_style_examples`: 100 fictional human-edited/audited natural examples, exported coverage package, exact package evaluation, and actual A-Mem run.
- `llm_memory_validation/human_style_examples/learned_writer_transfer`: coverage-blind learned writer transfer diagnostic trained on synthetic plus Natural-200 labels and tested on the human-edited package.
- `llm_memory_validation/human_style_examples/learned_writer_transfer_synth_only` and `llm_memory_validation/human_style_examples/learned_writer_transfer_natural_only`: training-source ablations for the learned writer transfer diagnostic.
- `llm_memory_validation/human_style_examples/writer_adapters`: denominator-matched Letta/MemGPT-style, A-Mem-style, Mem0-style, and A-MAC-style adapter diagnostics on the exported human-edited coverage package.
- `llm_memory_validation/natural_adjudicated_100_gemini_flash/writer_adapters`: denominator-matched Letta/MemGPT-style and A-Mem-style adapter diagnostics on the adjudicated natural package.
- `llm_memory_validation/natural_adjudicated_100_gemini_flash/faithful_memgpt_letta_union`: no-API faithful MemGPT/Letta core/archival baseline scored with a package-plus-written-store union denominator.
- `llm_memory_validation/natural_adjudicated_100_gemini_flash/actual_letta_openrouter_gemini_passage_87`: executable Letta server run on 87 adjudicated examples with OpenRouter Gemini, authenticated OpenRouter passage embeddings, archival-memory tools, and the union denominator.
- `llm_memory_validation/mem0_rescore_adjudicated100_gemini_flash`: Mem0 diagnostic rescoring on the adjudicated subset.
- `llm_memory_validation/natural_adjudicated_100_gemini_flash/actual_amem_gemini_flash_87`: executable public A-Mem run on 87 adjudicated examples using Gemini Flash and the union denominator.
- `llm_memory_validation/human_style_examples/actual_amem_gemini_flash_100`: executable public A-Mem run on the human-edited package using Gemini Flash and the union denominator.

See `artifact_manifest.md` for table-to-artifact mapping and full rerun
commands. See `REPRODUCIBILITY.md` for setup, Exact Package-Oracle runs, API runs, and
known local build limitations.

## Denominator Types

- Package ratio: exact ratio to `OPT_P(B)` for a finite MemAudit candidate package.
- Union ratio: exact ratio to `OPT_{P^+(Y)}(B)` after adding an external written store to the candidate package.
- Upper-pruned bound: best budget-feasible subset of an external store, used only to separate extraction quality from budget-aware selection.
- Retrieval/reader metrics: downstream diagnostics, not MemAudit optimum ratios.

## Caveats

The strongest exact claims are finite-package claims. LongMemEval-derived
natural coverage packages are model-adjudicated; the separate
`human_style_examples` package is human-edited/audited but does not include an
inter-annotator agreement file. LongMemEval reader/retrieval results
are downstream diagnostics and do not have exact OPT denominators. Mem0 and
A-Mem rescoring use union-denominator and upper-pruned-bound diagnostics rather
than claiming deployable optimal pruning policies.

Do not commit API keys. `api.env` is local-only and should stay ignored.

