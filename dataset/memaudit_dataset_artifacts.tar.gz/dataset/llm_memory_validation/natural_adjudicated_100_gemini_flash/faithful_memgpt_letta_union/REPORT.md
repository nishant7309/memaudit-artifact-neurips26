# Faithful MemGPT/Letta OracleMem Baseline

- Package: `llm_memory_validation\natural_adjudicated_100_gemini_flash\coverage_package`
- Queries evaluated: 87 / 87
- Budgets: `30,60,100,5000`
- API calls: 0.
- Denominator: exact finite union OPT over package candidates plus faithful MemGPT/Letta-written memories.
- System status: no-API faithful fallback, not a Letta server/API run.
- Letta checkout: `external_repos/letta` commit `bb52a89` version `0.16.7`.
- Actual Letta import probe: `not_importable`.

## Mean Ratio To Union OPT

| Method | B=30 | B=60 | B=100 | B=5000 |
| --- | ---: | ---: | ---: | ---: |
| `faithful_memgpt_letta_archival_search_pruned` | 0.746 | 0.739 | 0.866 | 0.919 |
| `faithful_memgpt_letta_recency_pruned` | 0.642 | 0.700 | 0.877 | 0.919 |
| `faithful_memgpt_letta_oracle_pruned_upper` | 0.829 | 0.907 | 0.939 | 0.919 |

## Claim Boundary

- The writer selects from exported package candidate texts using visible metadata only: representation type, generator label, confidence, cost, recency, and text tokens.
- Coverage labels are inherited only after writing, for no-API scoring; they are not used for admission or retrieval except in the analysis-only oracle upper row.
- `faithful_memgpt_letta_archival_search_pruned` is the main non-oracle query-time policy; it ranks written core/archival memories by lexical query overlap, visible score, tier, and recency.
- `faithful_memgpt_letta_recency_pruned` is a native recency/context diagnostic.
- `faithful_memgpt_letta_oracle_pruned_upper` uses hidden coverage and should be treated as an upper bound on the value present in the written store.
