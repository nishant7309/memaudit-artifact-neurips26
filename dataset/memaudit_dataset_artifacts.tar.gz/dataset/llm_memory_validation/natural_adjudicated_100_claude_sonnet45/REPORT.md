# Natural Package Adjudication Report

- Adjudicator model: `anthropic/claude-sonnet-4.5`
- Attempted examples: 87
- Accepted/corrected examples exported: 81
- Rejected/ambiguous examples: 6
- Required-unit changed rate: 0.069
- API total tokens: 660904
- API cost reported by OpenRouter: $3.2198

## Status Counts

- `accepted`: 57
- `ambiguous`: 1
- `corrected`: 24
- `rejected`: 5

## Adjudicated Package Scores

| Budget | Method | N | Mean ratio to exact package OPT | Bootstrap 95% CI |
|---:|---|---:|---:|---|
| 30 | `amem_graph` | 81 | 0.500 | [0.404, 0.602] |
| 30 | `estimated_gvt` | 81 | 0.501 | [0.401, 0.608] |
| 30 | `mem0_extract` | 81 | 0.574 | [0.469, 0.675] |
| 30 | `memgpt_tiered` | 81 | 0.605 | [0.503, 0.710] |
| 30 | `oracle_gvt` | 81 | 0.994 | [0.975, 1.000] |
| 60 | `amem_graph` | 81 | 0.460 | [0.369, 0.544] |
| 60 | `estimated_gvt` | 81 | 0.676 | [0.592, 0.764] |
| 60 | `mem0_extract` | 81 | 0.461 | [0.365, 0.550] |
| 60 | `memgpt_tiered` | 81 | 0.465 | [0.371, 0.556] |
| 60 | `oracle_gvt` | 81 | 0.996 | [0.988, 1.000] |
| 100 | `amem_graph` | 81 | 0.456 | [0.366, 0.539] |
| 100 | `estimated_gvt` | 81 | 0.805 | [0.736, 0.876] |
| 100 | `mem0_extract` | 81 | 0.461 | [0.367, 0.543] |
| 100 | `memgpt_tiered` | 81 | 0.464 | [0.372, 0.553] |
| 100 | `oracle_gvt` | 81 | 1.000 | [1.000, 1.000] |

## Claim Boundary

This is model adjudication with Gemini Flash, not human ground truth. It is useful as a stricter semantic-stability diagnostic than the primary single-annotator package, but any main-paper claim should still call it model-adjudicated rather than human-adjudicated.
