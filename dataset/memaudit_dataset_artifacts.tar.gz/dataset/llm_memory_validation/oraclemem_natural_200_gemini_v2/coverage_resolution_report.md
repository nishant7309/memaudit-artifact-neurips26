# Coverage Resolution Report

- Attempted/constructed instances: 200
- Coverage-resolved instances: 200
- Unresolved instances: 0
- Coverage-resolved rate: 1.000

An instance is coverage-resolved when the query annotation maps at least one required evidence unit to evidence units generated from the selected support/distractor sessions.
