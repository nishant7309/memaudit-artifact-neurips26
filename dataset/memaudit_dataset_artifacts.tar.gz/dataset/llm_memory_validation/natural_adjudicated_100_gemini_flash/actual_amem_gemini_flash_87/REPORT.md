# Actual A-Mem Natural Baseline

- Package: `llm_memory_validation\natural_adjudicated_100_gemini_flash\coverage_package`
- Queries attempted: 87
- A-Mem writer model: `google/gemini-2.5-flash`
- Coverage scorer model: `google/gemini-2.5-flash`
- Denominator: exact finite union OPT over package candidates plus A-Mem-written memories.
- System status: actual checked-out `external_repos/AgenticMemory` writer path, not the local `amem_graph` adapter.
- Cached API prompts: 524
- API tokens: 2433021
- Estimated OpenRouter cost: $1.576

## Mean Ratio To Union OPT

| Method | B=30 | B=60 | B=100 | B=5000 |
| --- | --- | --- | --- | --- |
| `actual_amem_full_native_retrieval_pruned` | 0.000 | 0.000 | 0.000 | 0.764 |
| `actual_amem_full_oracle_pruned_upper` | 0.000 | 0.000 | 0.000 | 0.845 |
| `actual_amem_full_recency_pruned` | 0.000 | 0.000 | 0.000 | 0.805 |
| `actual_amem_metadata_native_retrieval_pruned` | 0.180 | 0.158 | 0.180 | 0.248 |
| `actual_amem_metadata_oracle_pruned_upper` | 0.204 | 0.158 | 0.180 | 0.248 |
| `actual_amem_metadata_recency_pruned` | 0.191 | 0.158 | 0.151 | 0.248 |

## Notes

- `actual_amem_full_*` scores A-Mem's actual full stored notes. These can be much larger than the benchmark budgets.
- `actual_amem_metadata_*` scores a compact serialization of A-Mem-generated context/keywords/tags/links. This is a diagnostic view, not A-Mem's raw storage policy.
- `*_native_retrieval_pruned` uses A-Mem's query-time retriever, so it is a retrieval/context diagnostic rather than a pure write-time budget policy.
- `*_oracle_pruned_upper` is analysis-only and uses hidden coverage to upper-bound the value present in A-Mem's written store.