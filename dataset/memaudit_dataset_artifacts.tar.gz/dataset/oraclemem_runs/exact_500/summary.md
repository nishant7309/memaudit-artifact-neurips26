# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.

## Aggregate Results

| Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | `density_only` | 500 | 2.2610 | 0.9548 [0.9486, 0.9607] | 1.00 | 1.00 | yes |
| 1 | `fact_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| 1 | `no_tombstone_gvt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| 1 | `no_tombstone_opt` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| 1 | `opt` | 500 | 2.3705 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| 1 | `oracle_gvt` | 500 | 2.3705 | 1.0000 [1.0000, 1.0000] | 1.00 | 1.00 | yes |
| 1 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| 1 | `summary_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| 2 | `density_only` | 500 | 1.1868 | 0.2637 [0.2600, 0.2671] | 2.00 | 0.00 | yes |
| 2 | `fact_only` | 500 | 2.3525 | 0.5226 [0.5176, 0.5272] | 2.00 | 0.00 | yes |
| 2 | `no_tombstone_gvt` | 500 | 2.3525 | 0.5226 [0.5176, 0.5272] | 2.00 | 0.00 | yes |
| 2 | `no_tombstone_opt` | 500 | 2.3525 | 0.5226 [0.5176, 0.5272] | 2.00 | 0.00 | yes |
| 2 | `opt` | 500 | 4.5205 | 1.0000 [1.0000, 1.0000] | 2.00 | 2.00 | yes |
| 2 | `oracle_gvt` | 500 | 4.5205 | 1.0000 [1.0000, 1.0000] | 2.00 | 2.00 | yes |
| 2 | `recency_raw` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| 2 | `summary_only` | 500 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| 4 | `density_only` | 500 | 2.3952 | 0.3494 [0.3459, 0.3528] | 4.00 | 0.00 | yes |
| 4 | `fact_only` | 500 | 4.4900 | 0.6539 [0.6501, 0.6573] | 4.00 | 0.00 | yes |
| 4 | `no_tombstone_gvt` | 500 | 4.4900 | 0.6539 [0.6501, 0.6573] | 4.00 | 0.00 | yes |
| 4 | `no_tombstone_opt` | 500 | 4.4900 | 0.6539 [0.6501, 0.6573] | 4.00 | 0.00 | yes |
| 4 | `opt` | 500 | 6.8730 | 1.0000 [1.0000, 1.0000] | 4.00 | 2.00 | yes |
| 4 | `oracle_gvt` | 500 | 6.8510 | 0.9968 [0.9957, 0.9978] | 4.00 | 2.00 | yes |
| 4 | `recency_raw` | 500 | 0.1500 | 0.0219 [0.0218, 0.0220] | 4.00 | 0.00 | yes |
| 4 | `summary_only` | 500 | 3.5115 | 0.5111 [0.5097, 0.5124] | 4.00 | 0.75 | yes |
| 8 | `density_only` | 500 | 3.7304 | 0.3612 [0.3587, 0.3637] | 8.00 | 0.00 | yes |
| 8 | `fact_only` | 500 | 7.0108 | 0.6783 [0.6762, 0.6806] | 8.00 | 0.00 | yes |
| 8 | `no_tombstone_gvt` | 500 | 6.9071 | 0.6682 [0.6669, 0.6694] | 8.00 | 1.13 | yes |
| 8 | `no_tombstone_opt` | 500 | 7.1220 | 0.6891 [0.6876, 0.6906] | 8.00 | 0.51 | yes |
| 8 | `opt` | 500 | 10.3373 | 1.0000 [1.0000, 1.0000] | 8.00 | 2.00 | yes |
| 8 | `oracle_gvt` | 500 | 9.9079 | 0.9583 [0.9540, 0.9625] | 7.71 | 2.00 | yes |
| 8 | `recency_raw` | 500 | 3.2923 | 0.3185 [0.3170, 0.3200] | 6.00 | 0.45 | yes |
| 8 | `summary_only` | 500 | 6.7879 | 0.6566 [0.6558, 0.6573] | 8.00 | 1.50 | yes |
| 16 | `density_only` | 500 | 8.4009 | 0.6517 [0.6500, 0.6534] | 12.00 | 2.00 | yes |
| 16 | `fact_only` | 500 | 8.3704 | 0.6493 [0.6476, 0.6508] | 14.00 | 0.00 | yes |
| 16 | `no_tombstone_gvt` | 500 | 10.3753 | 0.8048 [0.8044, 0.8052] | 14.35 | 1.45 | yes |
| 16 | `no_tombstone_opt` | 500 | 10.5033 | 0.8148 [0.8143, 0.8151] | 16.00 | 1.50 | yes |
| 16 | `opt` | 500 | 12.8909 | 1.0000 [1.0000, 1.0000] | 16.00 | 2.00 | yes |
| 16 | `oracle_gvt` | 500 | 12.6995 | 0.9851 [0.9847, 0.9855] | 14.45 | 2.00 | yes |
| 16 | `recency_raw` | 500 | 6.7042 | 0.5201 [0.5187, 0.5216] | 16.00 | 0.90 | yes |
| 16 | `summary_only` | 500 | 8.9024 | 0.6906 [0.6901, 0.6912] | 14.00 | 1.50 | yes |

## Best Method by Budget

- Budget 1: `opt` with mean `ratio_to_opt=1.0000`.
- Budget 2: `opt` with mean `ratio_to_opt=1.0000`.
- Budget 4: `opt` with mean `ratio_to_opt=1.0000`.
- Budget 8: `opt` with mean `ratio_to_opt=1.0000`.
- Budget 16: `opt` with mean `ratio_to_opt=1.0000`.
