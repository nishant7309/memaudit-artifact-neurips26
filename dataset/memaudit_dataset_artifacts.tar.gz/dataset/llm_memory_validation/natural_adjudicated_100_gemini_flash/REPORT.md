# Natural Package Adjudication Report

- Adjudicator model: `google/gemini-2.5-flash`
- Attempted examples: 100
- Accepted/corrected examples exported: 87
- Rejected/ambiguous examples: 13
- Required-unit changed rate: 0.060
- API total tokens: 773689
- API cost reported by OpenRouter: $0.5197

## Status Counts

- `accepted`: 81
- `ambiguous`: 2
- `corrected`: 6
- `rejected`: 11

## Adjudicated Package Scores

| Budget | Method | N | Mean ratio to exact package OPT | Bootstrap 95% CI |
|---:|---|---:|---:|---|
| 30 | `amem_graph` | 87 | 0.481 | [0.381, 0.582] |
| 30 | `estimated_gvt` | 87 | 0.528 | [0.429, 0.622] |
| 30 | `fact_only` | 87 | 0.804 | [0.721, 0.881] |
| 30 | `mem0_extract` | 87 | 0.596 | [0.492, 0.695] |
| 30 | `opt` | 87 | 1.000 | [1.000, 1.000] |
| 30 | `oracle_gvt` | 87 | 1.000 | [1.000, 1.000] |
| 30 | `recency_raw` | 87 | 0.138 | [0.069, 0.218] |
| 30 | `summary_only` | 87 | 0.261 | [0.172, 0.359] |
| 60 | `amem_graph` | 87 | 0.374 | [0.275, 0.467] |
| 60 | `estimated_gvt` | 87 | 0.678 | [0.584, 0.761] |
| 60 | `fact_only` | 87 | 0.608 | [0.518, 0.697] |
| 60 | `mem0_extract` | 87 | 0.416 | [0.327, 0.506] |
| 60 | `opt` | 87 | 1.000 | [1.000, 1.000] |
| 60 | `oracle_gvt` | 87 | 0.996 | [0.989, 1.000] |
| 60 | `recency_raw` | 87 | 0.000 | [0.000, 0.000] |
| 60 | `summary_only` | 87 | 0.809 | [0.754, 0.864] |
| 100 | `amem_graph` | 87 | 0.377 | [0.284, 0.466] |
| 100 | `estimated_gvt` | 87 | 0.829 | [0.761, 0.887] |
| 100 | `fact_only` | 87 | 0.595 | [0.504, 0.683] |
| 100 | `mem0_extract` | 87 | 0.414 | [0.325, 0.503] |
| 100 | `opt` | 87 | 1.000 | [1.000, 1.000] |
| 100 | `oracle_gvt` | 87 | 1.000 | [1.000, 1.000] |
| 100 | `recency_raw` | 87 | 0.000 | [0.000, 0.000] |
| 100 | `summary_only` | 87 | 0.941 | [0.902, 0.972] |

## Claim Boundary

This is model adjudication with Gemini Flash, not human ground truth. It is useful as a stricter semantic-stability diagnostic than the primary single-annotator package, but any main-paper claim should still call it model-adjudicated rather than human-adjudicated.
