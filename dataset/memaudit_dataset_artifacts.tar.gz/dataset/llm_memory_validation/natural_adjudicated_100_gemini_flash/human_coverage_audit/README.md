# Human Coverage Audit

Fill `human_a_labels.csv` and `human_b_labels.csv` with binary labels.
Do not edit `annotation_cells.csv`; it is the immutable sampling frame.

Cells include all nonzero Gemini package coverage cells and a deterministic stratified sample of Gemini-zero cells.
The same schema definition used for model annotation should be used by human annotators.
