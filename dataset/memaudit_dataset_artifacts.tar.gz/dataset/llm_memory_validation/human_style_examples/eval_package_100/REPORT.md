# Human-Edited/Audited OracleMem Package Evaluation

- Source examples: `llm_memory_validation\human_style_examples\examples_100.jsonl`
- Records: 100
- Annotation status: human-edited/audited source examples as provided by the authors; no inter-annotator agreement file is included.
- Denominator: exact dynamic-programming optimum over the finite human-audited package.
- Aggregation: the 100 examples are evaluated as one finite package, so package-level ratios are reported rather than cross-annotator agreement statistics.

## Domain Counts

- `abstention-only`: 5
- `preference-update`: 20
- `privacy/deletion/do-not-store`: 10
- `procedural preference`: 10
- `scheduling/commitment`: 15
- `stale-fact/correction`: 15
- `temporal validity`: 10
- `tool-result/task-state`: 15

## Package Ratio To OPT

### Budget 150
- `amac_admission`: 0.533
- `amem_graph`: 0.667
- `density_only`: 0.600
- `estimated_gvt`: 0.867
- `fact_only`: 0.333
- `greedy`: 1.000
- `mem0_extract`: 0.267
- `memgpt_tiered`: 0.400
- `no_tombstone_opt`: 0.867
- `opt`: 1.000
- `oracle_gvt`: 1.000
- `recency_raw`: 0.000
- `summary_only`: 0.000

### Budget 300
- `amac_admission`: 0.593
- `amem_graph`: 0.741
- `density_only`: 0.667
- `estimated_gvt`: 0.852
- `fact_only`: 0.185
- `greedy`: 1.000
- `mem0_extract`: 0.444
- `memgpt_tiered`: 0.481
- `no_tombstone_opt`: 0.815
- `opt`: 1.000
- `oracle_gvt`: 0.963
- `recency_raw`: 0.000
- `summary_only`: 0.000

### Budget 600
- `amac_admission`: 0.625
- `amem_graph`: 0.750
- `density_only`: 0.854
- `estimated_gvt`: 0.792
- `fact_only`: 0.104
- `greedy`: 1.000
- `mem0_extract`: 0.542
- `memgpt_tiered`: 0.542
- `no_tombstone_opt`: 0.812
- `opt`: 1.000
- `oracle_gvt`: 0.958
- `recency_raw`: 0.000
- `summary_only`: 0.000

### Budget 1000
- `amac_admission`: 0.667
- `amem_graph`: 0.708
- `density_only`: 0.889
- `estimated_gvt`: 0.722
- `fact_only`: 0.069
- `greedy`: 1.000
- `mem0_extract`: 0.708
- `memgpt_tiered`: 0.625
- `no_tombstone_opt`: 0.625
- `opt`: 1.000
- `oracle_gvt`: 1.000
- `recency_raw`: 0.000
- `summary_only`: 0.000
