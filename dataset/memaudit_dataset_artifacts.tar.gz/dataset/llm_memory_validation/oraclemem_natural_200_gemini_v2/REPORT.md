# Gemini Natural OracleMem Pilot

This run uses Gemini through OpenRouter to build a LongMemEval-S support-slice coverage package.
It is stronger than synthetic-only evidence, but it is not yet a full non-synthetic benchmark because labels are single-model annotated and the haystack is sliced to answer-support sessions plus distractors.

## Source Repos Inspected

- `A-Mem`: `external_repos/AgenticMemory`
- `Letta/MemGPT`: `external_repos/letta`
- `Mem0`: `external_repos/mem0`

## API Usage

- New API calls: 681
- Cache hits: 0
- Total tokens: 1978327
- Estimated cost from OpenRouter usage: $0.9074
- Coverage-resolved instances: 200
- Unresolved instances with zero required units: 0

## Coverage Package

- `README`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\README.md`
- `annotation_decisions`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\annotation_decisions.jsonl`
- `candidate_generation_manifest`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\candidate_generation_manifest.json`
- `candidate_memories`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\candidate_memories.jsonl`
- `coverage_matrix`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\coverage_matrix.jsonl`
- `evidence_units`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\evidence_units.jsonl`
- `experiences`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\experiences.jsonl`
- `package_dir`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package`
- `queries`: `llm_memory_validation\oraclemem_natural_200_gemini_v2\coverage_package\queries.jsonl`

## Aggregate Results

- budget 30, `amac_admission`: ratio_to_opt=0.755, objective=0.445, cost=21.2, feasible=True
- budget 30, `amem_graph`: ratio_to_opt=0.693, objective=0.365, cost=19.9, feasible=True
- budget 30, `fact_only`: ratio_to_opt=0.850, objective=0.550, cost=7.9, feasible=True
- budget 30, `mem0_extract`: ratio_to_opt=0.760, objective=0.455, cost=21.0, feasible=True
- budget 30, `memgpt_tiered`: ratio_to_opt=0.772, objective=0.470, cost=21.3, feasible=True
- budget 30, `opt`: ratio_to_opt=1.000, objective=0.715, cost=9.9, feasible=True
- budget 30, `oracle_gvt`: ratio_to_opt=1.000, objective=0.715, cost=9.9, feasible=True
- budget 30, `recency_raw`: ratio_to_opt=0.380, objective=0.000, cost=0.0, feasible=True
- budget 30, `summary_only`: ratio_to_opt=0.477, objective=0.105, cost=2.8, feasible=True
- budget 60, `amac_admission`: ratio_to_opt=0.651, objective=0.520, cost=27.9, feasible=True
- budget 60, `amem_graph`: ratio_to_opt=0.633, objective=0.495, cost=29.9, feasible=True
- budget 60, `fact_only`: ratio_to_opt=0.736, objective=0.660, cost=10.0, feasible=True
- budget 60, `mem0_extract`: ratio_to_opt=0.659, objective=0.530, cost=27.9, feasible=True
- budget 60, `memgpt_tiered`: ratio_to_opt=0.662, objective=0.535, cost=28.2, feasible=True
- budget 60, `opt`: ratio_to_opt=1.000, objective=1.020, cost=18.7, feasible=True
- budget 60, `oracle_gvt`: ratio_to_opt=1.000, objective=1.020, cost=18.7, feasible=True
- budget 60, `recency_raw`: ratio_to_opt=0.295, objective=0.000, cost=0.0, feasible=True
- budget 60, `summary_only`: ratio_to_opt=0.873, objective=0.750, cost=26.5, feasible=True
- budget 100, `amac_admission`: ratio_to_opt=0.648, objective=0.525, cost=28.9, feasible=True
- budget 100, `amem_graph`: ratio_to_opt=0.641, objective=0.530, cost=31.6, feasible=True
- budget 100, `fact_only`: ratio_to_opt=0.726, objective=0.660, cost=10.0, feasible=True
- budget 100, `mem0_extract`: ratio_to_opt=0.656, objective=0.535, cost=28.8, feasible=True
- budget 100, `memgpt_tiered`: ratio_to_opt=0.660, objective=0.540, cost=29.1, feasible=True
- budget 100, `opt`: ratio_to_opt=1.000, objective=1.080, cost=21.0, feasible=True
- budget 100, `oracle_gvt`: ratio_to_opt=1.000, objective=1.080, cost=21.0, feasible=True
- budget 100, `recency_raw`: ratio_to_opt=0.295, objective=0.000, cost=0.0, feasible=True
- budget 100, `summary_only`: ratio_to_opt=0.982, objective=1.030, cost=38.2, feasible=True

## Coverage-Resolved Subset

These rows exclude examples whose required evidence units could not be resolved from the generated coverage package. This is the safer number for paper discussion.

- budget 30, `amac_admission`: n=200, ratio_to_opt=0.755, objective=0.445, cost=21.2
- budget 30, `amem_graph`: n=200, ratio_to_opt=0.693, objective=0.365, cost=19.9
- budget 30, `fact_only`: n=200, ratio_to_opt=0.850, objective=0.550, cost=7.9
- budget 30, `mem0_extract`: n=200, ratio_to_opt=0.760, objective=0.455, cost=21.0
- budget 30, `memgpt_tiered`: n=200, ratio_to_opt=0.772, objective=0.470, cost=21.3
- budget 30, `opt`: n=200, ratio_to_opt=1.000, objective=0.715, cost=9.9
- budget 30, `oracle_gvt`: n=200, ratio_to_opt=1.000, objective=0.715, cost=9.9
- budget 30, `recency_raw`: n=200, ratio_to_opt=0.380, objective=0.000, cost=0.0
- budget 30, `summary_only`: n=200, ratio_to_opt=0.477, objective=0.105, cost=2.8
- budget 60, `amac_admission`: n=200, ratio_to_opt=0.651, objective=0.520, cost=27.9
- budget 60, `amem_graph`: n=200, ratio_to_opt=0.633, objective=0.495, cost=29.9
- budget 60, `fact_only`: n=200, ratio_to_opt=0.736, objective=0.660, cost=10.0
- budget 60, `mem0_extract`: n=200, ratio_to_opt=0.659, objective=0.530, cost=27.9
- budget 60, `memgpt_tiered`: n=200, ratio_to_opt=0.662, objective=0.535, cost=28.2
- budget 60, `opt`: n=200, ratio_to_opt=1.000, objective=1.020, cost=18.7
- budget 60, `oracle_gvt`: n=200, ratio_to_opt=1.000, objective=1.020, cost=18.7
- budget 60, `recency_raw`: n=200, ratio_to_opt=0.295, objective=0.000, cost=0.0
- budget 60, `summary_only`: n=200, ratio_to_opt=0.873, objective=0.750, cost=26.5
- budget 100, `amac_admission`: n=200, ratio_to_opt=0.648, objective=0.525, cost=28.9
- budget 100, `amem_graph`: n=200, ratio_to_opt=0.641, objective=0.530, cost=31.6
- budget 100, `fact_only`: n=200, ratio_to_opt=0.726, objective=0.660, cost=10.0
- budget 100, `mem0_extract`: n=200, ratio_to_opt=0.656, objective=0.535, cost=28.8
- budget 100, `memgpt_tiered`: n=200, ratio_to_opt=0.660, objective=0.540, cost=29.1
- budget 100, `opt`: n=200, ratio_to_opt=1.000, objective=1.080, cost=21.0
- budget 100, `oracle_gvt`: n=200, ratio_to_opt=1.000, objective=1.080, cost=21.0
- budget 100, `recency_raw`: n=200, ratio_to_opt=0.295, objective=0.000, cost=0.0
- budget 100, `summary_only`: n=200, ratio_to_opt=0.982, objective=1.030, cost=38.2

## Interpretation Boundary

- Candidate generation is query-independent at the session level.
- Required-unit annotation uses the question and gold answer; this is benchmark labeling, not a writer input.
- The MemGPT/Mem0/A-Mem/A-MAC rows use local policy mappings over Gemini-generated candidate types. They are not full published-system executions unless a future adapter records that explicitly.
- This pilot is suitable as a NeurIPS rebuttal/progress artifact, not as the final main empirical table without scaling and adjudication.
