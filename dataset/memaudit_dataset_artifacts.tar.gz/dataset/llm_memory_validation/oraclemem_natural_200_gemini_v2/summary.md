# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.
- `policy_metadata`: Rows record estimated-policy, local proxy writer, validity-ablation, or candidate-quality-ablation provenance; train/dev estimated rows mark train-time oracle labels separately from dev-time visible-feature decisions and use no external services.
- `retrieval_summary`: Aggregated deterministic retrieval/write decomposition, emitted when --enable-retrieval is used.

## Local Proxy Writer Baselines

- `amac_admission`: proxy for A-MAC-style memory admission. Local proxy only: it does not run the published A-MAC policy, learned admission model, or task-specific reward estimator.
- `amem_graph`: proxy for A-Mem-style adaptive graph/evolving memory. Local proxy only: it does not run A-Mem's learned memory evolution, LLM-generated relation expansion, or retrieval-time graph traversal.
- `mem0_extract`: proxy for Mem0-style extraction and consolidation. Local proxy only: it does not run Mem0's extraction model, vector store, graph store, or update pipeline.
- `memgpt_tiered`: proxy for MemGPT-style tiered/context memory. Local proxy only: it does not run MemGPT's controller, paging loop, tool calls, summarizer, or retriever.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `unknown` | 30 | `amac_admission` | 200 | 0.4450 | 0.7550 [0.6925, 0.8125] | 21.23 | 0.04 | yes |
| `unknown` | 30 | `amem_graph` | 200 | 0.3650 | 0.6925 [0.6325, 0.7525] | 19.91 | 0.03 | yes |
| `unknown` | 30 | `fact_only` | 200 | 0.5500 | 0.8500 [0.7950, 0.9000] | 7.93 | 0.01 | yes |
| `unknown` | 30 | `mem0_extract` | 200 | 0.4550 | 0.7600 [0.6975, 0.8175] | 21.02 | 0.03 | yes |
| `unknown` | 30 | `memgpt_tiered` | 200 | 0.4700 | 0.7725 [0.7125, 0.8250] | 21.30 | 0.03 | yes |
| `unknown` | 30 | `opt` | 200 | 0.7150 | 1.0000 [1.0000, 1.0000] | 9.92 | 0.01 | yes |
| `unknown` | 30 | `oracle_gvt` | 200 | 0.7150 | 1.0000 [1.0000, 1.0000] | 9.92 | 0.01 | yes |
| `unknown` | 30 | `recency_raw` | 200 | 0.0000 | 0.3800 [0.3150, 0.4450] | 0.00 | 0.00 | yes |
| `unknown` | 30 | `summary_only` | 200 | 0.1050 | 0.4775 [0.4100, 0.5475] | 2.81 | 0.01 | yes |
| `unknown` | 60 | `amac_admission` | 200 | 0.5200 | 0.6508 [0.5892, 0.7133] | 27.91 | 0.04 | yes |
| `unknown` | 60 | `amem_graph` | 200 | 0.4950 | 0.6333 [0.5700, 0.6958] | 29.95 | 0.03 | yes |
| `unknown` | 60 | `fact_only` | 200 | 0.6600 | 0.7358 [0.6733, 0.7942] | 10.02 | 0.01 | yes |
| `unknown` | 60 | `mem0_extract` | 200 | 0.5300 | 0.6592 [0.5967, 0.7208] | 27.90 | 0.03 | yes |
| `unknown` | 60 | `memgpt_tiered` | 200 | 0.5350 | 0.6625 [0.6000, 0.7208] | 28.17 | 0.04 | yes |
| `unknown` | 60 | `opt` | 200 | 1.0200 | 1.0000 [1.0000, 1.0000] | 18.70 | 0.01 | yes |
| `unknown` | 60 | `oracle_gvt` | 200 | 1.0200 | 1.0000 [1.0000, 1.0000] | 18.70 | 0.01 | yes |
| `unknown` | 60 | `recency_raw` | 200 | 0.0000 | 0.2950 [0.2350, 0.3550] | 0.00 | 0.00 | yes |
| `unknown` | 60 | `summary_only` | 200 | 0.7500 | 0.8725 [0.8433, 0.9025] | 26.54 | 0.03 | yes |
| `unknown` | 100 | `amac_admission` | 200 | 0.5250 | 0.6479 [0.5871, 0.7092] | 28.86 | 0.04 | yes |
| `unknown` | 100 | `amem_graph` | 200 | 0.5300 | 0.6412 [0.5783, 0.7025] | 31.64 | 0.03 | yes |
| `unknown` | 100 | `fact_only` | 200 | 0.6600 | 0.7262 [0.6633, 0.7842] | 10.02 | 0.01 | yes |
| `unknown` | 100 | `mem0_extract` | 200 | 0.5350 | 0.6562 [0.5925, 0.7167] | 28.80 | 0.03 | yes |
| `unknown` | 100 | `memgpt_tiered` | 200 | 0.5400 | 0.6596 [0.5954, 0.7179] | 29.11 | 0.04 | yes |
| `unknown` | 100 | `opt` | 200 | 1.0800 | 1.0000 [1.0000, 1.0000] | 21.02 | 0.02 | yes |
| `unknown` | 100 | `oracle_gvt` | 200 | 1.0800 | 1.0000 [1.0000, 1.0000] | 21.02 | 0.02 | yes |
| `unknown` | 100 | `recency_raw` | 200 | 0.0000 | 0.2950 [0.2350, 0.3550] | 0.00 | 0.00 | yes |
| `unknown` | 100 | `summary_only` | 200 | 1.0300 | 0.9822 [0.9693, 0.9933] | 38.23 | 0.03 | yes |

## Best Method by Budget

- `unknown`, budget 30: `opt` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 60: `opt` with mean `ratio_to_opt=1.0000`.
- `unknown`, budget 100: `opt` with mean `ratio_to_opt=1.0000`.

## Deterministic Decomposition

| Distribution | Budget | Method | Mode | Write Fail | Retrieval Fail | Reader Fail | Stale Retrieved | Retrieved Units |
| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: |
| `unknown` | 30 | `amac_admission` | `fixed` | 5.33 | 0.00 | 0.00 | 0.00 | 2.81 |
| `unknown` | 30 | `amac_admission` | `oracle` | 5.33 | 0.00 | 0.00 | 0.00 | 2.81 |
| `unknown` | 30 | `amem_graph` | `fixed` | 5.40 | 0.00 | 0.00 | 0.00 | 2.73 |
| `unknown` | 30 | `amem_graph` | `oracle` | 5.40 | 0.00 | 0.00 | 0.00 | 2.73 |
| `unknown` | 30 | `fact_only` | `fixed` | 7.09 | 0.00 | 0.00 | 0.00 | 1.04 |
| `unknown` | 30 | `fact_only` | `oracle` | 7.09 | 0.00 | 0.00 | 0.00 | 1.04 |
| `unknown` | 30 | `mem0_extract` | `fixed` | 5.37 | 0.00 | 0.00 | 0.00 | 2.77 |
| `unknown` | 30 | `mem0_extract` | `oracle` | 5.37 | 0.00 | 0.00 | 0.00 | 2.77 |
| `unknown` | 30 | `memgpt_tiered` | `fixed` | 5.36 | 0.00 | 0.00 | 0.00 | 2.78 |
| `unknown` | 30 | `memgpt_tiered` | `oracle` | 5.36 | 0.00 | 0.00 | 0.00 | 2.78 |
| `unknown` | 30 | `opt` | `fixed` | 6.79 | 0.00 | 0.00 | 0.00 | 1.34 |
| `unknown` | 30 | `opt` | `oracle` | 6.79 | 0.00 | 0.00 | 0.00 | 1.34 |
| `unknown` | 30 | `oracle_gvt` | `fixed` | 6.82 | 0.00 | 0.00 | 0.00 | 1.31 |
| `unknown` | 30 | `oracle_gvt` | `oracle` | 6.82 | 0.00 | 0.00 | 0.00 | 1.31 |
| `unknown` | 30 | `recency_raw` | `fixed` | 8.13 | 0.00 | 0.00 | 0.00 | 0.00 |
| `unknown` | 30 | `recency_raw` | `oracle` | 8.13 | 0.00 | 0.00 | 0.00 | 0.00 |
| `unknown` | 30 | `summary_only` | `fixed` | 7.78 | 0.00 | 0.00 | 0.00 | 0.35 |
| `unknown` | 30 | `summary_only` | `oracle` | 7.78 | 0.00 | 0.00 | 0.00 | 0.35 |
| `unknown` | 60 | `amac_admission` | `fixed` | 4.52 | 0.09 | 0.00 | 0.00 | 3.53 |
| `unknown` | 60 | `amac_admission` | `oracle` | 4.52 | 0.00 | 0.00 | 0.00 | 3.62 |
| `unknown` | 60 | `amem_graph` | `fixed` | 4.16 | 0.04 | 0.00 | 0.00 | 3.93 |
| `unknown` | 60 | `amem_graph` | `oracle` | 4.16 | 0.00 | 0.00 | 0.00 | 3.98 |
| `unknown` | 60 | `fact_only` | `fixed` | 6.87 | 0.00 | 0.00 | 0.00 | 1.27 |
| `unknown` | 60 | `fact_only` | `oracle` | 6.87 | 0.00 | 0.00 | 0.00 | 1.27 |
| `unknown` | 60 | `mem0_extract` | `fixed` | 4.50 | 0.09 | 0.00 | 0.00 | 3.56 |
| `unknown` | 60 | `mem0_extract` | `oracle` | 4.50 | 0.00 | 0.00 | 0.00 | 3.64 |
| `unknown` | 60 | `memgpt_tiered` | `fixed` | 4.51 | 0.09 | 0.00 | 0.00 | 3.54 |
| `unknown` | 60 | `memgpt_tiered` | `oracle` | 4.51 | 0.00 | 0.00 | 0.00 | 3.62 |
| `unknown` | 60 | `opt` | `fixed` | 5.93 | 0.00 | 0.00 | 0.00 | 2.20 |
| `unknown` | 60 | `opt` | `oracle` | 5.93 | 0.00 | 0.00 | 0.00 | 2.20 |
| `unknown` | 60 | `oracle_gvt` | `fixed` | 5.94 | 0.00 | 0.00 | 0.00 | 2.19 |
| `unknown` | 60 | `oracle_gvt` | `oracle` | 5.94 | 0.00 | 0.00 | 0.00 | 2.19 |
| `unknown` | 60 | `recency_raw` | `fixed` | 8.13 | 0.00 | 0.00 | 0.00 | 0.00 |
| `unknown` | 60 | `recency_raw` | `oracle` | 8.13 | 0.00 | 0.00 | 0.00 | 0.00 |
| `unknown` | 60 | `summary_only` | `fixed` | 5.58 | 0.00 | 0.00 | 0.00 | 2.55 |
| `unknown` | 60 | `summary_only` | `oracle` | 5.58 | 0.00 | 0.00 | 0.00 | 2.55 |
| `unknown` | 100 | `amac_admission` | `fixed` | 4.41 | 0.16 | 0.00 | 0.00 | 3.56 |
| `unknown` | 100 | `amac_admission` | `oracle` | 4.41 | 0.00 | 0.00 | 0.00 | 3.73 |
| `unknown` | 100 | `amem_graph` | `fixed` | 4.00 | 0.16 | 0.00 | 0.00 | 3.98 |
| `unknown` | 100 | `amem_graph` | `oracle` | 4.00 | 0.00 | 0.00 | 0.00 | 4.13 |
| `unknown` | 100 | `fact_only` | `fixed` | 6.87 | 0.00 | 0.00 | 0.00 | 1.27 |
| `unknown` | 100 | `fact_only` | `oracle` | 6.87 | 0.00 | 0.00 | 0.00 | 1.27 |
| `unknown` | 100 | `mem0_extract` | `fixed` | 4.39 | 0.17 | 0.00 | 0.00 | 3.58 |
| `unknown` | 100 | `mem0_extract` | `oracle` | 4.39 | 0.00 | 0.00 | 0.00 | 3.74 |
| `unknown` | 100 | `memgpt_tiered` | `fixed` | 4.42 | 0.17 | 0.00 | 0.00 | 3.55 |
| `unknown` | 100 | `memgpt_tiered` | `oracle` | 4.42 | 0.00 | 0.00 | 0.00 | 3.71 |
| `unknown` | 100 | `opt` | `fixed` | 5.74 | 0.03 | 0.00 | 0.00 | 2.37 |
| `unknown` | 100 | `opt` | `oracle` | 5.74 | 0.00 | 0.00 | 0.00 | 2.40 |
| `unknown` | 100 | `oracle_gvt` | `fixed` | 5.75 | 0.03 | 0.00 | 0.00 | 2.37 |
| `unknown` | 100 | `oracle_gvt` | `oracle` | 5.75 | 0.00 | 0.00 | 0.00 | 2.39 |
| `unknown` | 100 | `recency_raw` | `fixed` | 8.13 | 0.00 | 0.00 | 0.00 | 0.00 |
| `unknown` | 100 | `recency_raw` | `oracle` | 8.13 | 0.00 | 0.00 | 0.00 | 0.00 |
| `unknown` | 100 | `summary_only` | `fixed` | 4.57 | 0.00 | 0.00 | 0.00 | 3.57 |
| `unknown` | 100 | `summary_only` | `oracle` | 4.57 | 0.00 | 0.00 | 0.00 | 3.57 |
