# OracleMem MVP Summary

Exact-small synthetic benchmark with sparse semantic coverage, one budget, and one representation per experience.

## Ratio Labels

- `ratio_to_opt`: F(method_store) / F(exact_opt_store); emitted only when exact optimum is certified.
- `ratio_to_upper_bound`: F(method_store) / certified_upper_bound; exact-small uses exact OPT as the upper bound.
- `ratio_to_reference`: F(method_store) / F(greedy_reference_store); never labeled as OPT.
- `denominator_label`: Source of the primary oracle denominator for ratio_to_opt.
- `policy_metadata`: Rows record estimated-policy, local proxy writer, validity-ablation, or candidate-quality-ablation provenance; train/dev estimated rows mark train-time oracle labels separately from dev-time visible-feature decisions and use no external services.
- `retrieval_summary`: Aggregated deterministic retrieval/write decomposition, emitted when --enable-retrieval is used.

## Local Proxy Writer Baselines

- `amac_admission`: proxy for A-MAC-style memory admission. Local proxy only: it does not run the published A-MAC policy, learned admission model, or task-specific reward estimator.
- `amem_graph`: proxy for A-Mem-style adaptive graph/evolving memory. Faithful local adapter only: it does not run A-Mem's learned memory evolution, LLM-generated relation expansion, or retrieval-time graph traversal.
- `mem0_extract`: proxy for Mem0-style extraction and consolidation. Local proxy only: it does not run Mem0's extraction model, vector store, graph store, or update pipeline.
- `memgpt_tiered`: proxy for Letta/MemGPT-style archival/recency tiered memory. Faithful local adapter only: it does not run a Letta server, MemGPT's controller, paging loop, tool calls, summarizer, or retriever.

## Aggregate Results

| Distribution | Budget | Method | N | Mean Objective | Mean Ratio to OPT | Mean Cost | Mean Invalidation Covered | Feasible |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `human_audited` | 150 | `amac_admission` | 1 | 8.0000 | 0.5333 [0.5333, 0.5333] | 148.00 | 3.00 | yes |
| `human_audited` | 150 | `amem_graph` | 1 | 10.0000 | 0.6667 [0.6667, 0.6667] | 147.00 | 2.00 | yes |
| `human_audited` | 150 | `density_only` | 1 | 9.0000 | 0.6000 [0.6000, 0.6000] | 150.00 | 9.00 | yes |
| `human_audited` | 150 | `estimated_gvt` | 1 | 14.0000 | 0.9333 [0.9333, 0.9333] | 146.00 | 4.00 | yes |
| `human_audited` | 150 | `estimated_utility` | 1 | 13.0000 | 0.8667 [0.8667, 0.8667] | 147.00 | 3.00 | yes |
| `human_audited` | 150 | `fact_only` | 1 | 5.0000 | 0.3333 [0.3333, 0.3333] | 92.00 | 0.00 | yes |
| `human_audited` | 150 | `greedy` | 1 | 15.0000 | 1.0000 [1.0000, 1.0000] | 141.00 | 3.00 | yes |
| `human_audited` | 150 | `mem0_extract` | 1 | 4.0000 | 0.2667 [0.2667, 0.2667] | 147.00 | 1.00 | yes |
| `human_audited` | 150 | `memgpt_tiered` | 1 | 6.0000 | 0.4000 [0.4000, 0.4000] | 143.00 | 2.00 | yes |
| `human_audited` | 150 | `no_tombstone_opt` | 1 | 13.0000 | 0.8667 [0.8667, 0.8667] | 150.00 | 3.00 | yes |
| `human_audited` | 150 | `opt` | 1 | 15.0000 | 1.0000 [1.0000, 1.0000] | 141.00 | 3.00 | yes |
| `human_audited` | 150 | `oracle_gvt` | 1 | 15.0000 | 1.0000 [1.0000, 1.0000] | 141.00 | 3.00 | yes |
| `human_audited` | 150 | `recency_raw` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `human_audited` | 150 | `summary_only` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `human_audited` | 300 | `amac_admission` | 1 | 16.0000 | 0.5926 [0.5926, 0.5926] | 291.00 | 7.00 | yes |
| `human_audited` | 300 | `amem_graph` | 1 | 20.0000 | 0.7407 [0.7407, 0.7407] | 292.00 | 8.00 | yes |
| `human_audited` | 300 | `density_only` | 1 | 18.0000 | 0.6667 [0.6667, 0.6667] | 299.00 | 12.00 | yes |
| `human_audited` | 300 | `estimated_gvt` | 1 | 25.0000 | 0.9259 [0.9259, 0.9259] | 293.00 | 5.00 | yes |
| `human_audited` | 300 | `estimated_utility` | 1 | 23.0000 | 0.8519 [0.8519, 0.8519] | 298.00 | 5.00 | yes |
| `human_audited` | 300 | `fact_only` | 1 | 5.0000 | 0.1852 [0.1852, 0.1852] | 92.00 | 0.00 | yes |
| `human_audited` | 300 | `greedy` | 1 | 27.0000 | 1.0000 [1.0000, 1.0000] | 289.00 | 6.00 | yes |
| `human_audited` | 300 | `mem0_extract` | 1 | 12.0000 | 0.4444 [0.4444, 0.4444] | 297.00 | 7.00 | yes |
| `human_audited` | 300 | `memgpt_tiered` | 1 | 13.0000 | 0.4815 [0.4815, 0.4815] | 294.00 | 6.00 | yes |
| `human_audited` | 300 | `no_tombstone_opt` | 1 | 22.0000 | 0.8148 [0.8148, 0.8148] | 285.00 | 5.00 | yes |
| `human_audited` | 300 | `opt` | 1 | 27.0000 | 1.0000 [1.0000, 1.0000] | 289.00 | 7.00 | yes |
| `human_audited` | 300 | `oracle_gvt` | 1 | 26.0000 | 0.9630 [0.9630, 0.9630] | 295.00 | 10.00 | yes |
| `human_audited` | 300 | `recency_raw` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `human_audited` | 300 | `summary_only` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `human_audited` | 600 | `amac_admission` | 1 | 30.0000 | 0.6250 [0.6250, 0.6250] | 600.00 | 17.00 | yes |
| `human_audited` | 600 | `amem_graph` | 1 | 36.0000 | 0.7500 [0.7500, 0.7500] | 599.00 | 20.00 | yes |
| `human_audited` | 600 | `density_only` | 1 | 41.0000 | 0.8542 [0.8542, 0.8542] | 599.00 | 25.00 | yes |
| `human_audited` | 600 | `estimated_gvt` | 1 | 41.0000 | 0.8542 [0.8542, 0.8542] | 600.00 | 15.00 | yes |
| `human_audited` | 600 | `estimated_utility` | 1 | 39.0000 | 0.8125 [0.8125, 0.8125] | 599.00 | 13.00 | yes |
| `human_audited` | 600 | `fact_only` | 1 | 5.0000 | 0.1042 [0.1042, 0.1042] | 92.00 | 0.00 | yes |
| `human_audited` | 600 | `greedy` | 1 | 48.0000 | 1.0000 [1.0000, 1.0000] | 585.00 | 11.00 | yes |
| `human_audited` | 600 | `mem0_extract` | 1 | 26.0000 | 0.5417 [0.5417, 0.5417] | 600.00 | 16.00 | yes |
| `human_audited` | 600 | `memgpt_tiered` | 1 | 26.0000 | 0.5417 [0.5417, 0.5417] | 598.00 | 14.00 | yes |
| `human_audited` | 600 | `no_tombstone_opt` | 1 | 39.0000 | 0.8125 [0.8125, 0.8125] | 592.00 | 6.00 | yes |
| `human_audited` | 600 | `opt` | 1 | 48.0000 | 1.0000 [1.0000, 1.0000] | 585.00 | 15.00 | yes |
| `human_audited` | 600 | `oracle_gvt` | 1 | 46.0000 | 0.9583 [0.9583, 0.9583] | 595.00 | 16.00 | yes |
| `human_audited` | 600 | `recency_raw` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `human_audited` | 600 | `summary_only` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `human_audited` | 1000 | `amac_admission` | 1 | 48.0000 | 0.6667 [0.6667, 0.6667] | 987.00 | 24.00 | yes |
| `human_audited` | 1000 | `amem_graph` | 1 | 51.0000 | 0.7083 [0.7083, 0.7083] | 988.00 | 24.00 | yes |
| `human_audited` | 1000 | `density_only` | 1 | 64.0000 | 0.8889 [0.8889, 0.8889] | 998.00 | 25.00 | yes |
| `human_audited` | 1000 | `estimated_gvt` | 1 | 57.0000 | 0.7917 [0.7917, 0.7917] | 999.00 | 23.00 | yes |
| `human_audited` | 1000 | `estimated_utility` | 1 | 56.0000 | 0.7778 [0.7778, 0.7778] | 990.00 | 23.00 | yes |
| `human_audited` | 1000 | `fact_only` | 1 | 5.0000 | 0.0694 [0.0694, 0.0694] | 92.00 | 0.00 | yes |
| `human_audited` | 1000 | `greedy` | 1 | 72.0000 | 1.0000 [1.0000, 1.0000] | 984.00 | 19.00 | yes |
| `human_audited` | 1000 | `mem0_extract` | 1 | 51.0000 | 0.7083 [0.7083, 0.7083] | 993.00 | 24.00 | yes |
| `human_audited` | 1000 | `memgpt_tiered` | 1 | 45.0000 | 0.6250 [0.6250, 0.6250] | 998.00 | 24.00 | yes |
| `human_audited` | 1000 | `no_tombstone_opt` | 1 | 45.0000 | 0.6250 [0.6250, 0.6250] | 741.00 | 6.00 | yes |
| `human_audited` | 1000 | `opt` | 1 | 72.0000 | 1.0000 [1.0000, 1.0000] | 984.00 | 22.00 | yes |
| `human_audited` | 1000 | `oracle_gvt` | 1 | 72.0000 | 1.0000 [1.0000, 1.0000] | 993.00 | 22.00 | yes |
| `human_audited` | 1000 | `recency_raw` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |
| `human_audited` | 1000 | `summary_only` | 1 | 0.0000 | 0.0000 [0.0000, 0.0000] | 0.00 | 0.00 | yes |

## Best Method by Budget

- `human_audited`, budget 150: `greedy` with mean `ratio_to_opt=1.0000`.
- `human_audited`, budget 300: `greedy` with mean `ratio_to_opt=1.0000`.
- `human_audited`, budget 600: `greedy` with mean `ratio_to_opt=1.0000`.
- `human_audited`, budget 1000: `greedy` with mean `ratio_to_opt=1.0000`.
