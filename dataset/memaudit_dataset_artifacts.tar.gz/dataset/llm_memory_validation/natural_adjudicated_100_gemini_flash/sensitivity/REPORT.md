# MemAudit Cost and Constraint Sensitivity

All rows are deterministic recomputations from cached package/export artifacts; no API calls are made.

## Package group-capacity sensitivity

| B | OPT k=1 | OPT k=2 | k=2/k=1 | byte-overhead k=1 | byte/default |
|---:|---:|---:|---:|---:|---:|
| 30 | 0.931 | 0.943 | 1.013 | 1.310 | 1.322 |
| 60 | 1.356 | 1.374 | 1.027 | 1.483 | 1.107 |
| 100 | 1.489 | 1.540 | 1.060 | 1.632 | 1.131 |

## Exported-system sensitivity at B=100

| Cost rule | Method | Mean ratio to package OPT | N |
|---|---|---:|---:|
| word | amem_full_native | 0.000 | 87 |
| word | amem_metadata_recency | 0.190 | 87 |
| word | letta_salience | 0.899 | 87 |
| word | letta_upper | 0.939 | 87 |
| word | mem0_salience | 0.489 | 87 |
| word | mem0_upper | 1.041 | 87 |
| byte_overhead | amem_full_native | 0.000 | 87 |
| byte_overhead | amem_metadata_recency | 0.266 | 87 |
| byte_overhead | letta_salience | 0.800 | 87 |
| byte_overhead | letta_upper | 0.831 | 87 |
| byte_overhead | mem0_salience | 0.442 | 87 |
| byte_overhead | mem0_upper | 0.933 | 87 |

A-Mem full native rows are zero at B=100 because the full serialized notes are far above the small budgets.
Mean minimum full-note cost is 1767.9 words and 463.5 byte-overhead units.
