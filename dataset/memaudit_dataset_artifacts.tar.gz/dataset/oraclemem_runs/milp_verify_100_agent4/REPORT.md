# MILP Verify Report

Date: 2026-04-28

Optional PuLP MILP support was already present in `oraclemem/solvers_milp.py`; no solver-code changes were required. This run audits the MILP backend against the pure-stdlib branch-and-bound exact solver on 100 seeds across `base`, `update_chain`, and `temporal_interval`.

Result: 1200/1200 objective-value matches, max absolute difference 0.0.

The CLI budget fractions `0.02,0.05,0.10,0.20` resolved to absolute budgets `1,4,7,15` because the average generated candidate cost was 73.48.

| Distribution | Seeds | Budgets | Exact objective matches | Max abs diff | B&B median sec | MILP median sec |
| --- | ---: | --- | ---: | ---: | ---: | ---: |
| `base` | 100 | `1,4,7,15` | 400/400 | 0 | 0.003805 | 0.054898 |
| `temporal_interval` | 100 | `1,4,7,15` | 400/400 | 0 | 0.026843 | 0.053885 |
| `update_chain` | 100 | `1,4,7,15` | 400/400 | 0 | 0.001106 | 0.026970 |

Overall median runtime:

| Solver | Median sec |
| --- | ---: |
| Branch-and-bound exact stdlib | 0.002078 |
| PuLP MILP | 0.049467 |

The MILP and branch-and-bound solvers selected different candidate ID sets in 426/1200 cases, but every such case had identical certified objective value. This is expected when multiple optimal stores tie under binary cap-1 coverage.

Companion branch-and-bound timing mirror: `oraclemem_runs/milp_verify_100_agent4_exact_stdlib/`.
