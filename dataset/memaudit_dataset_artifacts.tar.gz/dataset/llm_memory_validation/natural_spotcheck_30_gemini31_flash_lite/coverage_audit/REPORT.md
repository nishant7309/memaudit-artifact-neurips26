# Coverage Artifact Audit

This report checks whether existing artifacts expose the machine-readable fields needed for non-synthetic OracleMem coverage annotation. It is a structural audit only; it does not certify semantic label quality.

## Verdict

Coverage-ready package candidates detected: `natural_spotcheck_30_gemini31_flash_lite`.

## Artifact Matrix

| Artifact | Rows | Evidence | Query Requirements | Candidates | Coverage | Denominator Status | First Gap |
| --- | ---: | --- | --- | --- | --- | --- | --- |
| `natural_spotcheck_30_gemini31_flash_lite` | 705 | unit-level present | unit requirements present | candidate records present | candidate-unit coverage present | machine-checkable coverage package | No structural gap detected. |

## Completeness Signals

| Artifact | Sampled | Unit IDs | Required Units | Gold Sessions | Candidate IDs | Selected IDs | Coverage | Context/Used IDs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `natural_spotcheck_30_gemini31_flash_lite` | 705 | 0.445 | 0.082 | 0.041 | 0.468 | 0.000 | 0.091 | 0.000 |

## Acceptance Gate

Synthetic exact-small OracleMem instances can be exported for structural inspection with `python run_oraclemem_mvp.py --export-coverage-matrices`; pass an exported package directory to this script with `--artifact name=path/to/coverage_instances/base/seed_0`.

To upgrade a non-synthetic LongMemEval/LoCoMo-style artifact from diagnostic to exact OracleMem coverage, add the package described in `COVERAGE_VALIDATION_PROTOCOL.md`: `evidence_units.jsonl`, `queries.jsonl` with `required_unit_ids`, `candidate_memories.jsonl`, `coverage_matrix.jsonl`, annotation decisions, and a candidate-generation manifest.

Hard blockers for non-synthetic coverage are 100% schema completeness for eval queries, evidence units, positive coverage rows, candidate groups/costs, no future-source coverage, no generator leakage, and solver inputs derivable from the artifacts without hidden code defaults.

| Acceptance item | Required threshold |
| --- | ---: |
| Eval queries with answer/category/session ids/adjudicated required units | 100% |
| Required unit ids resolvable in `evidence_units.jsonl` | 100% |
| Evidence units source-backed and adjudication resolved | 100% |
| Positive coverage rows valid, sourced, rationalized, resolved | 100% |
| Candidate groups, representation types, text, and costs valid | 100% |
| Future-source coverage leakage | 0 rows |
| Forbidden generator inputs leaked | 0 records |
| Binary coverage agreement before adjudication | kappa >= 0.70 |
| None/partial/full coverage agreement before adjudication | weighted kappa >= 0.60 |
| Unit candidate availability at coverage >= 0.75 | >= 0.95 |
| Query feasible support before budget | >= 0.90 |
| Update/current-truth support for validity claims | >= 0.90 |
| Hallucinated coverage after adjudication | 0 rows |
