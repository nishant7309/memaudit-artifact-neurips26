# Gemini Natural OracleMem Coverage Package

This is a LongMemEval-S support-slice pilot, not a finalized human-adjudicated benchmark.
Candidate generation used only conversation sessions. Query/gold answer was used only to annotate required evidence units.

Instances: 200
Evidence units: 1723
Candidate memories: 1706
Positive coverage rows: 5066
