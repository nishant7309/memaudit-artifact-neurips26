# LongMemEval-S Focus Report

- Source: LongMemEval-S frozen retrieval artifact
- Focus types: `knowledge-update`, `temporal-reasoning`
- Metric basis: gold answer_session_ids retrieval only; no answer generation and no exact OPT
- Scope: retrieval-only. This report does not measure abstention, answer accuracy, stale answers, or ratio to OPT.

## Focus Retrieval

| Method | Overall R@5 | Focus R@5 | Focus 95% CI | Focus MRR@5 | Delta vs full dense RAG | Delta vs budgeted raw dense |
|---|---:|---:|---:|---:|---:|---:|
| OracleMem writer + dense retrieval | 0.9516 | 0.9469 | [0.9194, 0.9716] | 0.9250 | +0.0833 | +0.7472 |
| Full raw-store dense retrieval | 0.8846 | 0.8637 | [0.8239, 0.8983] | 0.8728 | +0.0000 | +0.6640 |
| Budgeted raw replay + dense retrieval | 0.2056 | 0.1997 | [0.1610, 0.2428] | 0.3349 | -0.6640 | +0.0000 |
| FIFO raw replay | 0.2254 | 0.2084 | [0.1690, 0.2477] | 0.3681 | -0.6553 | +0.0087 |

## Focus Retrieval K-Sweep

This artifact contains top-5 retrieval ids, so the sweep reports R@1/R@3/R@5 and MRR@5. R@10 requires regenerating retrieval rows with `topk=10`.

| Method | Focus R@1 | Focus R@3 | Focus R@5 | Focus MRR@5 |
|---|---:|---:|---:|---:|
| OracleMem writer + dense retrieval | 0.4573 | 0.8886 | 0.9469 | 0.9250 |
| Full raw-store dense retrieval | 0.4115 | 0.7879 | 0.8637 | 0.8728 |
| Budgeted raw replay + dense retrieval | 0.1547 | 0.1926 | 0.1997 | 0.3349 |
| FIFO raw replay | 0.1721 | 0.2039 | 0.2084 | 0.3681 |

## Per-Type Retrieval

| Method | Knowledge-update R@5 | Temporal-reasoning R@5 | Multi-session R@5 |
|---|---:|---:|---:|
| OracleMem writer + dense retrieval | 0.9872 | 0.9233 | 0.9624 |
| Full raw-store dense retrieval | 0.8846 | 0.8514 | 0.9327 |
| Budgeted raw replay + dense retrieval | 0.2308 | 0.1815 | 0.2683 |
| FIFO raw replay | 0.2692 | 0.1727 | 0.1934 |

## Interpretation

- The strongest budgeted memory writer in this artifact is `dense_budgeted_bsc` (reported as OracleMem writer + dense retrieval), which exceeds full raw-store dense retrieval on the focused update/temporal slice.
- The comparison is retrieval-only and uses LongMemEval-S gold answer-session ids; it should be cited as a diagnostic transfer check, not as main answer-accuracy evidence or as an oracle-ratio result.
- LongMemEval-S in this local pipeline does not expose an abstention category, so abstention and stale-answer claims still require a separate reader/evaluation run.
